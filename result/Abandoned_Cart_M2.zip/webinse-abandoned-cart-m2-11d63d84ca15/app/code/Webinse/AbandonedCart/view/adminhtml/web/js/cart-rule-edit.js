require([
        "jquery"
    ],
    function($) {
        function template() {
            var url = $('li[data-ui-id="menu-magento-email-template"] a').attr('href');
            var size = $('div.cart-rule-edit .admin__control-select option').size();
            if (size <= 0){
                $('div.cart-rule-edit .admin__field-note').html('<span style="color: red">You must create a template! Click</span> <a href="'+url+'">here.</a>');
            }
        }
        setTimeout(template, 3000);
    });
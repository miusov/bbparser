define([
    "jquery"
],
    function($) {

    function checkout() {

        $('input[type="email"]').focusout(function () {
            var email = $(this).val();
            $.ajax({
                url:'http://freegeoip.net/json/',
                type:'get',
                dataType:'json'
            }).done(function(data) {
                var ip = data.ip;
                if (ip){
                    console.log(ip);
                    if (email){
                        if ( /^([a-z0-9_-]+\.)*[a-z0-9_-]+@[a-z0-9_-]+(\.[a-z0-9_-]+)*\.[a-z]{2,6}$/.test(email) ) {
                            console.log(email+' - verify');
                            var param = {'ip':ip,'email':email};
                            $.ajax({
                                url: '/abandonedcart/abandoned/checkout',
                                type: 'post',
                                data: param,
                                dataType: 'json',
                                success: function (data) {
                                    console.log(data);
                                },
                                error: function () {
                                    console.log('ERROR');
                                }
                            })
                        }else{
                            console.log(email+' - not verify');
                        }
                    }
                }
            });

        })
    }
    var pathName = window.location.pathname;
    if(pathName == '/checkout/cart/'){
        setTimeout(checkout, 3000);
    }
});
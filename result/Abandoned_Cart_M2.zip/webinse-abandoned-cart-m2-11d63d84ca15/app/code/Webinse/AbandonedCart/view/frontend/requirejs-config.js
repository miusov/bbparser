/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category design
​ * ​ ​ @package AbandonedCart
​ * ​ ​ @author
 *   Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright​ ​ 2018​ ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */

var config = {
    deps: [
        "Webinse_AbandonedCart/js/main"
        // "Webinse_AbandonedCart/js/admin-config"
    ]
};
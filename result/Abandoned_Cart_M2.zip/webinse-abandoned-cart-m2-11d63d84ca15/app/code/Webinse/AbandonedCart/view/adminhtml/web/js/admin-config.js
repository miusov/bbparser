require([
        "jquery"
    ],
    function($) {

        $('#send_test_email').prop('disabled', true);
        $('#send_button').prop('disabled', true);
        var email = $('#abandonedcart_sender_config_sender_email').val();

        if ( /^([a-z0-9_-]+\.)*[a-z0-9_-]+@[a-z0-9_-]+(\.[a-z0-9_-]+)*\.[a-z]{2,6}$/.test(email) ) {
            $('tr#row_abandonedcart_sender_config_button p.note').text('');
            $('#send_test_email').prop('disabled', false);
        }else{
            $('tr#row_abandonedcart_sender_config_button p.note').text('Invalid Email address!');
        }

        if ($('#abandonedcart_abandonedcart_group_autosend').val() == 1)
        {
            $('tr#row_abandonedcart_abandonedcart_group_send_button p.note').text('');
            $('#send_button').prop('disabled', false);
        }

    });
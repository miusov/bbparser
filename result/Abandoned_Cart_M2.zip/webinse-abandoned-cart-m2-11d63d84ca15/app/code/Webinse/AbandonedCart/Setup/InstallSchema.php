<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
namespace Webinse\AbandonedCart\Setup;

use Magento\Framework\Setup;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements Setup\InstallSchemaInterface
{
    public function install(Setup\SchemaSetupInterface $setup, Setup\ModuleContextInterface $context)
    {
        $setup->startSetup();

        $table = $setup->getConnection()->newTable(
            $setup->getTable('email_log')
        )->addColumn(
            'entity_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'auto_increment' => true, 'nullable'=>false, 'primary' => true],
            'ID'
        )->addColumn(
            'status',
            Table::TYPE_TEXT,
            255,
            [],
            'Status'
        )->addColumn(
            'quantity',
            Table::TYPE_INTEGER,
            11,
            ['default'=>0],
            'Quantity'
        )->addColumn(
            'coupon',
            Table::TYPE_TEXT,
            255,
            ['default'=> 'NO'],
            'Coupon'
        )->addColumn(
            'customer_first_name',
            Table::TYPE_TEXT,
            255,
            [],
            'Customer First Name'
        )->addColumn(
            'customer_last_name',
            Table::TYPE_TEXT,
            255,
            [],
            'Customer Last Name'
        )->addColumn(
            'customer_email',
            Table::TYPE_TEXT,
            255,
            [],
            'Customer Email'
        )->addColumn(
            'recovered_at',
            Table::TYPE_DATETIME,
            null,
            ['default'=> NULL],
            'Recovered At'
        )->addColumn(
            'sent_at',
            Table::TYPE_DATETIME,
            null,
            ['nullable' => false],
            'Sent At'
        )->addColumn(
            'abandoned_at',
            Table::TYPE_DATETIME,
            null,
            ['nullable' => false],
            'Abandoned At'
        )->setComment(
            'Emails log table'
        );
        $setup->getConnection()->createTable($table);

        $table = $setup->getConnection()->newTable(
            $setup->getTable('black_list')
        )->addColumn(
            'entity_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'auto_increment' => true, 'nullable'=>false, 'primary' => true],
            'ID'
        )->addColumn(
            'customer_email',
            Table::TYPE_TEXT,
            255,
            [],
            'Customer Email'
        )->setComment(
            'Black List table'
        );
        $setup->getConnection()->createTable($table);

        $table = $setup->getConnection()->newTable(
            $setup->getTable('cart_checkout')
        )->addColumn(
            'entity_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'auto_increment' => true, 'nullable'=>false, 'primary' => true],
            'ID'
        )->addColumn(
            'customer_id',
            Table::TYPE_INTEGER,
            11,
            ['default'=>0],
            'Customer ID'
        )->addColumn(
            'email',
            Table::TYPE_TEXT,
            255,
            [],
            'Customer Email'
        )->addColumn(
            'first_name',
            Table::TYPE_TEXT,
            255,
            ['default'=>'Guest'],
            'First Name'
        )->addColumn(
            'last_name',
            Table::TYPE_TEXT,
            255,
            ['default'=>'Guest'],
            'Last Name'
        )->addColumn(
            'grand_total',
            Table::TYPE_INTEGER,
            11,
            [],
            'Grand total'
        )->addColumn(
            'items_count',
            Table::TYPE_INTEGER,
            11,
            [],
            'Items Count'
        )->addColumn(
            'created_at',
            Table::TYPE_DATETIME,
            null,
            [],
            'Created at'
        )->addColumn(
            'updated_at',
            Table::TYPE_DATETIME,
            null,
            [],
            'Updated at'
        )->addColumn(
            'customer_is_guest',
            Table::TYPE_INTEGER,
            11,
            [],
            'Is Guest'
        )->addColumn(
            'customer_group_id',
            Table::TYPE_INTEGER,
            11,
            ['default'=>0],
            'Customer Group'
        )->setComment(
            'Cart Checkout'
        );
        $setup->getConnection()->createTable($table);

        $table = $setup->getConnection()->newTable(
            $setup->getTable('webinse_ac_rules')
        )->addColumn(
            'entity_id',
            Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'auto_increment' => true, 'nullable'=>false, 'primary' => true],
            'ID'
        )->addColumn(
            'enable',
            Table::TYPE_INTEGER,
            11,
            ['default'=>0],
            'Enable'
        )->addColumn(
            'title',
            Table::TYPE_TEXT,
            255,
            ['default'=>0],
            'Title'
        )->addColumn(
            'description',
            Table::TYPE_TEXT,
            1024,
            [],
            'Description'
        )->addColumn(
            'template',
            Table::TYPE_INTEGER,
            11,
            [],
            'Email Template'
        )->addColumn(
            'coupon',
            Table::TYPE_INTEGER,
            11,
            [],
            'Coupon'
        )->addColumn(
            'store',
            Table::TYPE_INTEGER,
            11,
            ['nullable' => false],
            'Store'
        )->addColumn(
            'customer_group',
            Table::TYPE_INTEGER,
            11,
            ['nullable' => false],
            'Customer Group'
        )->setComment(
            'Rules'
        );
        $setup->getConnection()->createTable($table);

        $setup->endSetup();
    }
}
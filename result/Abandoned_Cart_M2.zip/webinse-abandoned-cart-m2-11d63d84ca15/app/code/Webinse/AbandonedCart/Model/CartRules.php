<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
namespace Webinse\AbandonedCart\Model;

use Magento\Framework\Model\AbstractModel;
use Magento\Framework\DataObject\IdentityInterface;
use Webinse\AbandonedCart\Api\Data\CartRulesInterface;

class CartRules extends AbstractModel implements CartRulesInterface, IdentityInterface
{
    const CACHE_TAG = 'webinse_abandonedcart_cartrules';

    protected $_cacheTag = 'webinse_abandonedcart_cartrules';

    protected $_eventPrefix = 'webinse_abandonedcart_cartrules';

    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Webinse\AbandonedCart\Model\ResourceModel\CartRules');
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getId()
    {
        return $this->getData(self::ID);
    }

    public function getEnable()
    {
        return $this->getData(self::ENABLE);
    }

    public function getTitle()
    {
        return $this->getData(self::TITLE);
    }

    public function getDescription()
    {
        return $this->getData(self::DESCRIPTION);
    }

    public function getTemplate()
    {
        return $this->getData(self::TEMPLATE);
    }

    public function getStore()
    {
        return $this->getData(self::STORE);
    }

    public function getCustomerGroup()
    {
        return $this->getData(self::CUSTOMER_GROUP);
    }

    public function getCoupon()
    {
        return $this->getData(self::COUPON);
    }

    public function getAddCoupon()
    {
        return $this->getData(self::ADD_COUPON);
    }

    public function getCouponOption()
    {
        return $this->getData(self::COUPON_OPTION);
    }

    public function getExpire()
    {
        return $this->getData(self::EXPIRE);
    }

    public function getDiscountType()
    {
        return $this->getData(self::DISCOUNT_TYPE);
    }

    public function getDiscount()
    {
        return $this->getData(self::DISCOUNT);
    }

    public function getCouponLabel()
    {
        return $this->getData(self::COUPON_LABEL);
    }


    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }

    public function setEnable($enable)
    {
        return $this->setData(self::ENABLE, $enable);
    }

    public function setTitle($title)
    {
        return $this->setData(self::TITLE, $title);
    }

    public function setDescription($description)
    {
        return $this->setData(self::DESCRIPTION, $description);
    }

    public function setTemplate($template)
    {
        return $this->setData(self::TEMPLATE, $template);
    }

    public function setStore($store)
    {
        return $this->setData(self::STORE, $store);
    }

    public function setCustomerGroup($customer_group)
    {
        return $this->setData(self::CUSTOMER_GROUP, $customer_group);
    }

    public function setCoupon($coupon)
    {
        return $this->setData(self::COUPON, $coupon);
    }

    public function setAddCoupon($add_coupon)
    {
        return $this->setData(self::ADD_COUPON, $add_coupon);
    }

    public function setCouponOption($coupon_option)
    {
        return $this->setData(self::COUPON_OPTION, $coupon_option);
    }

    public function setExpire($expire)
    {
        return $this->setData(self::EXPIRE, $expire);
    }

    public function setDiscountType($discount_type)
    {
        return $this->setData(self::DISCOUNT_TYPE, $discount_type);
    }

    public function setDiscount($discount)
    {
        return $this->setData(self::DISCOUNT, $discount);
    }

    public function setCouponLabel($coupon_label)
    {
        return $this->setData(self::COUPON_LABEL, $coupon_label);
    }
}
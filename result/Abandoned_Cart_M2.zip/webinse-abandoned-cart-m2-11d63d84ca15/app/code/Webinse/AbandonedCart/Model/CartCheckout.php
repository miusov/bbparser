<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
namespace Webinse\AbandonedCart\Model;

use Magento\Framework\Model\AbstractModel;
use Webinse\AbandonedCart\Api\Data\CartCheckoutInterface;
use Magento\Framework\DataObject\IdentityInterface;

class CartCheckout extends AbstractModel implements CartCheckoutInterface, IdentityInterface
{
    const CACHE_TAG = 'webinse_abandonedcart_cartcheckout';

    protected $_cacheTag = 'webinse_abandonedcart_cartcheckout';

    protected $_eventPrefix = 'webinse_abandonedcart_cartcheckout';

    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Webinse\AbandonedCart\Model\ResourceModel\CartCheckout');
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getId()
    {
        return $this->getData(self::ID);
    }

    public function getCustomerEmail()
    {
        return $this->getData(self::CUSTOMER_EMAIL);
    }

    public function getGrandTotal()
    {
        return $this->getData(self::GRAND_TOTAL);
    }

    public function getItemsCount()
    {
        return $this->getData(self::ITEMS_COUNT);
    }

    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    public function getUpdatedAt()
    {
        return $this->getData(self::UPDATED_AT);
    }

    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }

    public function setCustomerEmail($customer_email)
    {
        return $this->setData(self::CUSTOMER_EMAIL, $customer_email);
    }

    public function setGrandTotal($grand_total)
    {
        return $this->setData(self::GRAND_TOTAL, $grand_total);
    }

    public function setItemsCount($items_count)
    {
        return $this->setData(self::ITEMS_COUNT, $items_count);
    }

    public function setCreatedAt($created_at)
    {
        return $this->setData(self::CREATED_AT, $created_at);
    }

    public function setUpdatedAt($updated_at)
    {
        return $this->setData(self::UPDATED_AT, $updated_at);
    }
}
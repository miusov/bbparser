<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
namespace Webinse\AbandonedCart\Model;

use Magento\Store\Model\StoreManager;
use Magento\Framework\Mail\Template\TransportBuilder;
use Psr\Log\LoggerInterface;
use Magento\SalesRule\Model\Rule;
use Magento\Customer\Model\Group;
use Magento\SalesRule\Model\Coupon\Codegenerator;
use Magento\Reports\Model\ResourceModel\Quote\CollectionFactory as QuoteCollectionFactory;
use Webinse\AbandonedCart\Model\ResourceModel\EmailLog\CollectionFactory as EmailLogCollectionFactory;
use Webinse\AbandonedCart\Model\ResourceModel\BlackList\CollectionFactory as BlackListCollectionFactory;
use Webinse\AbandonedCart\Model\ResourceModel\CartRules\CollectionFactory as CartRulesCollectionFactory;
use Webinse\AbandonedCart\Model\ResourceModel\CartCheckout\CollectionFactory as CartCheckoutFactory;
use Magento\CatalogInventory\Api\StockStateInterface as StockInterface;
use Magento\Quote\Model\ResourceModel\Quote\Item\CollectionFactory as QuoteFactory;

class Cron
{
    protected $_logger;
    protected $_storeManager;
    protected $_config;
    protected $_collectionFactory;
    protected $_blackListCollectionFactory;
    private   $transportBuilder;
    protected $_emailLogModel;
    protected $_emailLogCollectionFactory;
    protected $_ruleModel;
    protected $_customerGroupModel;
    protected $_codegeneratorModel;
    protected $_cartRules;
    protected $_cartCheckoutFacrory;
    protected $_stockFactory;
    protected $_quoteFactory;

    public function __construct(
        LoggerInterface $logger,
        StoreManager $storeManager,
        Config $config,
        QuoteCollectionFactory $collectionFactory,
        EmailLog $emailLogModel,
        Rule $ruleModel,
        Group $customerGroupModel,
        Codegenerator $codegeneratorModel,
        EmailLogCollectionFactory $emailLogCollectionFactory,
        BlackListCollectionFactory $blackListCollectionFactory,
        TransportBuilder $transportBuilder,
        CartCheckoutFactory $cartCheckoutFactory,
        StockInterface $stock_interface,
        QuoteFactory $quoteFactory,
        CartRulesCollectionFactory $cartRulesCollection
    )
    {
        $this->_logger                      = $logger;
        $this->_storeManager                = $storeManager;
        $this->_config                      = $config;
        $this->_collectionFactory           = $collectionFactory;
        $this->_blackListCollectionFactory  = $blackListCollectionFactory;
        $this->transportBuilder             = $transportBuilder;
        $this->_emailLogModel               = $emailLogModel;
        $this->_emailLogCollectionFactory   = $emailLogCollectionFactory;
        $this->_ruleModel                   = $ruleModel;
        $this->_customerGroupModel          = $customerGroupModel;
        $this->_codegeneratorModel          = $codegeneratorModel;
        $this->_cartRules                   = $cartRulesCollection;
        $this->_cartCheckoutFacrory         = $cartCheckoutFactory;
        $this->_stockFactory                = $stock_interface;
        $this->_quoteFactory                = $quoteFactory;
    }


    public function abandoned($auto_send = 1)
    {
        if ($this->_config->getAutoSend() == 0) $auto_send = 0;

        $module_enable = $this->_config->getEnableExtensionYesNo();
        $rules = $this->_cartRules->create();
        $rules->getData();

        if ($module_enable == 1)
        {
            foreach ($rules as $rule)
            {
                if ($rule['enable'] == 1)
                {
                    $this->_proccess(
                        $rule['store'],
                        $rule['template'],
                        $rule['customer_group'],
                        $auto_send,
                        $rule['coupon'],
                        $rule['add_coupon'],
                        $rule['coupon_option'],
                        $rule['expire'],
                        $rule['discount_type'],
                        $rule['discount'],
                        $rule['$coupon_label']
                    );
                }
            }
        }
    }

    /**
     * @param $today
     * @param $lastUpdate
     * @return int|string
     */
    public function dateInterval($today,$lastUpdate)
    {
        if (isset($lastUpdate))
        {
            $datetime1 = date_create($lastUpdate);
            $datetime2 = date_create($today);
            $interval = date_diff($datetime1, $datetime2);
            return $interval->format('%d');
        }
        return 1;
    }


    protected function _proccess(
        $storeId,
        $template,
        $customer_group,
        $auto_send,
        $coupon_yes_no,
        $add_coupon,
        $coupon_option,
        $expire,
        $discount_type,
        $discount,
        $coupon_label
)
    {
        $config             = $this->_config;
        $baseURL            = $this->_storeManager->getStore()->getBaseUrl();
        $email_log          = $this->_emailLogModel;
        $min_days           = $config->getMinDays();
        $sender_name        = $config->getSenderName();
        $sender_email       = $config->getSenderEmail();
        $message_delay      = $config->getMessageDelay();
        $max_quantity       = (int)$config->getMaxQuantity();
        $now                = date('Y-m-d H:i:s');
        $createCoupon       = $coupon_yes_no;
        $numEmailCoupon     = $add_coupon;


        /**
         * Get Abandoned Cart Collection
         */
        $abandoned_cart_collection = $this->_collectionFactory->create();
        $abandoned_cart_collection->prepareForAbandonedReport([$storeId]);
        $rows = $abandoned_cart_collection->load();
        $carts = $rows->getItems();

        $cartsInfo = [];
        $cartInfo = [];
        foreach ($carts as $cart)
        {
            if ($this->dateInterval($now,$cart->getUpdateAt()) >= $min_days)
            {
                $cartInfo['quote_id']           = $cart->getId();
                $cartInfo['customer_id']        = $cart->getCustomerId();
                $cartInfo['customer_group_id']  = $cart->getCustomerGroupId();
                $cartInfo['first_name']         = $cart->getCustomerFirstname();
                $cartInfo['last_name']          = $cart->getCustomerLastname();
                $cartInfo['email']              = $cart->getCustomerEmail();
                $cartInfo['grand_total']        = $cart->getGrandTotal();
                $cartInfo['items_count']        = $cart->getItemsCount();
                $cartInfo['updated_at']         = $cart->getUpdatedAt();
                $cartInfo['customer_is_guest']  = $cart->getCustomerIsGuest();
                $cartsInfo[] = $cartInfo;
            }
        }
        /**
         * Get unregistered customers
         */

        if ($this->_config->getRegisterYesNo() == 0)
        {
            $cart_checkout_collection = $this->_cartCheckoutFacrory->create()->getData();
            $cartsInfo = array_merge($cartsInfo,$cart_checkout_collection);
        }

        /**
         * Get Black List and filter only email
         */
        $black_list_collection = $this->_blackListCollectionFactory->create();
        $data = $black_list_collection->getData();
        $black_list_emails = [];

        foreach ($data as $item)
        {
            $black_list_emails[] = $item['customer_email'];
        }

        /**
         * Send email
         */
        $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $storeId);
        $from = array('email' => $sender_email, 'name' => $sender_name);

        foreach ($cartsInfo as $cartInf)
        {
            /**
             * item check
             */
            $continue = 0;
            if (isset($cartInf['quote_id']))
            {
                $quote_collection = $this->_quoteFactory->create()
                    ->addFieldToFilter('quote_id',$cartInf['quote_id'])
                    ->getData();

                $catalog_inventory = $this->_stockFactory;
                foreach ($quote_collection as $quote)
                {
                    $qty = (int)$quote['qty'];
                    $stock_qty = (int)$catalog_inventory->getStockQty($quote['product_id'],$storeId);
                    if ($qty > $stock_qty)
                    {
                        $continue = 1;
                        break;
                    }
                }
            }
            if ($continue == 1) continue;

            /**
             * adding an entry to a table 'email_log'
             */
            $emailLogCollection = $this->_emailLogCollectionFactory->create()
                ->addFieldToFilter('customer_email', ["eq" => $cartInf['email']]);
            $data = $emailLogCollection->getData();

            $email_log_emails = [];
            $email_log_quantity = '';
            $email_log_id ='';
            $email_log_recovered = '';
            $token = base64_encode('prefix_'.$cartInf['email']);

            foreach ($data as $item)
            {
                $email_log_id = $item['entity_id'];
                $email_log_emails[] = $item['customer_email'];
                $email_log_quantity = (int)$item['quantity'];
                $email_log_recovered = $item['recovered_at'];
            }

            if( !in_array($cartInf['email'],$black_list_emails)
                && ($email_log_quantity < $max_quantity)
                && $cartInf['customer_group_id'] == $customer_group
                && ($email_log_recovered == NULL || $email_log_recovered == '' || $email_log_recovered == 0)
                && $auto_send == 0 )
            {

                $templateVars = [
                    'customerId'        => $cartInf['customer_id'],
                    'token'             => base64_encode('prefix_'.$cartInf['email']),
                    'baseURL'           => $baseURL,
                    'firstName'         => $cartInf['first_name'],
                    'lastName'          => $cartInf['last_name'],
                    'customerEmail'     => $cartInf['email'],
                    'grandTotal'        => $cartInf['grand_total'],
                    'itemsCount'        => $cartInf['items_count'],
                    'updatedAt'         => $cartInf['updated_at']
                ];

                if (isset($cartInf['quote_id'])) $templateVars += ['acUrl' => $baseURL.'abandonedcart/abandoned/loadquote?id='.$cartInf['quote_id'].'&cid='.$cartInf['customer_id'].'&token='.$token];

                if($createCoupon == 1 && $email_log_quantity >= $numEmailCoupon)
                {
                    $coupon = $this->_createNewCoupon(
                        $storeId,
                        $cartInf['email'],
                        $coupon_option,
                        $expire,
                        $discount_type,
                        $discount,
                        $coupon_label
                    );
                    $email_log->load($email_log_id);
                    $email_log->setData('coupon','YES')->save();
                    $templateVars += [
                        'couponId'          => $coupon[0],
                        'couponDiscount'    => $discount,
                        'couponToDate'      => $coupon[2]
                    ];
                }

                $transport = $this->transportBuilder->setTemplateIdentifier($template)
                    ->setTemplateOptions($templateOptions)
                    ->setTemplateVars($templateVars)
                    ->setFrom($from)
                    ->addTo($cartInf['email'])
                    ->getTransport();
                $transport->sendMessage();

                if( in_array($cartInf['email'],$email_log_emails) )
                {
                    $email_log_quantity ++;

                    $email_log->load($email_log_id);
                    $email_log->setData('status','Sent');
                    $email_log->setData('quantity',$email_log_quantity);
                    $email_log->setData('customer_first_name',$cartInf['first_name']);
                    $email_log->setData('customer_last_name',$cartInf['last_name']);
                    $email_log->setData('customer_email',$cartInf['email']);
                    $email_log->setData('sent_at',date('Y-m-d H:i:s'));
                    $email_log->setData('abandoned_at',$cartInf['updated_at']);
                    $email_log->save();

                    $this->_logger->info('UPDATE OLD EMAIL!!! - '.$cartInf['email']);

                    unset($email_log_emails);
                    sleep($message_delay);
                }
                else
                {
                    $email_log->setData([
                        'status' => 'Sent',
                        'quantity' => 1,
                        'customer_first_name' => $cartInf['first_name'],
                        'customer_last_name' => $cartInf['last_name'],
                        'customer_email' => $cartInf['email'],
                        'sent_at' => date('Y-m-d H:i:s'),
                        'abandoned_at' => $cartInf['updated_at']
                    ])->save();

                    $this->_logger->info('ADD NEW EMAIL!!! - '.$cartInf['email']);

                    unset($email_log_emails);
                    sleep($message_delay);
                }
            }
        }
    }

    public function _createNewCoupon(
        $store,
        $email,
        $coupon_option,
        $expire,
        $discount_type,
        $discount,
        $coupon_label
    )
    {
        $coupon_type        = $discount_type;
        $coupon_amount      = $discount;
        $coupon_length      = 10;
        $coupon_expire_days = $expire;

        $collection = $this->_ruleModel->getCollection()
            ->addFieldToFilter('name', ['like' => 'Abandoned coupon ' . $email]);
        if (!count($collection)) {
            $websiteid = $this->_storeManager->getStore()->getWebsiteId();

            $fromDate = date("Y-m-d");
            $toDate = date('Y-m-d', strtotime($fromDate . " + $coupon_expire_days day"));
            if ($coupon_type == 1) {
                $action = 'cart_fixed';
                $discount = $this->_storeManager->getStore()->getCurrentCurrencyCode() . "$coupon_amount";
            } elseif ($coupon_type == 2) {
                $action = 'by_percent';
                $discount = "$coupon_amount%";
            }

            $customer_group = $this->_customerGroupModel->getCollection();
            $allGroups = $customer_group->toOptionHash();
            $groups = array();
            foreach ($allGroups as $groupid => $name) {
                $groups[] = $groupid;
            }

            $coupon_rule = $this->_ruleModel;
            $coupon_rule->setName("Abandoned coupon $email")
                ->setDescription("Abandoned coupon $email")
                ->setStopRulesProcessing(0)
                ->setFromDate($fromDate)
                ->setToDate($toDate)
                ->setIsActive(1)
                ->setCouponType($coupon_option)
                ->setUsesPerCoupon(1)
                ->setUsesPerCustomer(1)
                ->setCustomerGroupIds($groups)
                ->setProductIds('')
                ->setLengthMin($coupon_length)
                ->setLengthMax($coupon_length)
                ->setSortOrder(0)
                ->setStoreLabels(array($coupon_label))
                ->setSimpleAction($action)
                ->setDiscountAmount($coupon_amount)
                ->setDiscountQty(0)
                ->setDiscountStep('0')
                ->setSimpleFreeShipping('0')
                ->setApplyToShipping('0')
                ->setIsRss(0)
                ->setWebsiteIds($websiteid);
            $uniqueId = $this->_codegeneratorModel
                ->setLengthMin($coupon_length)
                ->setLengthMax($coupon_length)
                ->generateCode();
            $coupon_rule->setCouponCode($uniqueId);
            $coupon_rule->save();
            return array($uniqueId, $discount, $toDate);
        } else {
            $coupon = $collection->getFirstItem();
            if ($coupon->getSimpleAction() == 'cart_fixed') {
                $discount = $this->_storeManager->getStore()->getCurrentCurrencyCode() . ($coupon->getDiscountAmount() + 0);
            } else {
                $discount = $coupon->getDiscountAmount() + 0;
            }
            return array($coupon->getCode(), $discount, $coupon->getToDate());
        }
    }
}
<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
namespace Webinse\AbandonedCart\Model;


use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;

class Config
{

    protected $_scopeConfig;
    protected $_storeId = null;
    protected $_storeManager;

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager
    )
    {
        $this->_scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
    }


    public function getStoreId()
    {
        if ($this->_storeId === null) {
            $this->_storeId = (int)$this->_storeManager->getStore()->getId();
        }
        return $this->_storeId;
    }


    public function getEnableExtensionYesNo()
    {
        return $this->_scopeConfig->getValue("abandonedcart/abandonedcart_group/enabled_extension_yes_no", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getAutoSend()
    {
        return $this->_scopeConfig->getValue("abandonedcart/abandonedcart_group/autosend", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getMinDays()
    {
        return $this->_scopeConfig->getValue("abandonedcart/abandonedcart_group/min_days", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getSendingHours()
    {
        return $this->_scopeConfig->getValue("abandonedcart/abandonedcart_group/hours", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }
    public function getSenderName()
    {
        return $this->_scopeConfig->getValue("abandonedcart/sender_config/sender_name", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getSenderEmail()
    {
        return $this->_scopeConfig->getValue("abandonedcart/sender_config/sender_email", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getEmailTemplateId()
    {
        return $this->_scopeConfig->getValue("abandonedcart/abandonedcart_group/email_template", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getMessageDelay()
    {
        return $this->_scopeConfig->getValue("abandonedcart/abandonedcart_group/message_delay", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getRegisterYesNo()
    {
        return $this->_scopeConfig->getValue("abandonedcart/abandonedcart_group/register_yes_no", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getMaxQuantity()
    {
        return $this->_scopeConfig->getValue("abandonedcart/abandonedcart_group/max_quantity", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }



    //COUPON
    public function getCreateYesNo()
    {
        return $this->_scopeConfig->getValue("abandonedcart/coupon/create", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getOptionCoupon()
    {
        return $this->_scopeConfig->getValue("abandonedcart/coupon/couponoption", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getAddCoupon()
    {
        return $this->_scopeConfig->getValue("abandonedcart/coupon/add_coupon", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getExpire()
    {
        return $this->_scopeConfig->getValue("abandonedcart/coupon/expire", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getCouponLength()
    {
        return $this->_scopeConfig->getValue("abandonedcart/coupon/length", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getDiscountType()
    {
        return $this->_scopeConfig->getValue("abandonedcart/coupon/discounttype", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getDiscuontAmount()
    {
        return $this->_scopeConfig->getValue("abandonedcart/coupon/discount", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }

    public function getCouponLabel()
    {
        return $this->_scopeConfig->getValue("abandonedcart/coupon/couponlabel", ScopeInterface::SCOPE_STORE, (int)$this->getStoreId());
    }
}
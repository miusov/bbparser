<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
namespace Webinse\AbandonedCart\Api\Data;

interface CartRulesInterface
{
    const ID                = 'entity_id';
    const ENABLE            = 'enable';
    const TITLE             = 'title';
    const DESCRIPTION       = 'description';
    const TEMPLATE          = 'template';
    const STORE             = 'store';
    const CUSTOMER_GROUP    = 'customer_group';
    const COUPON            = 'coupon';
    const ADD_COUPON        = 'add_coupon';
    const COUPON_OPTION     = 'coupon_option';
    const EXPIRE            = 'expire';
    const DISCOUNT_TYPE     = 'discount_type';
    const DISCOUNT          = 'discount';
    const COUPON_LABEL      = 'coupon_label';


    /**
     * Get entity id.
     *
     * @return int
     */
    public function getId();

    /**
     * @return mixed
     */
    public function getEnable();

    /**
     * @return mixed
     */
    public function getTitle();

    /**
     * @return mixed
     */
    public function getDescription();

    /**
     * @return mixed
     */
    public function getTemplate();

    /**
     * @return mixed
     */
    public function getStore();

    /**
     * @return mixed
     */
    public function getCustomerGroup();

    /**
     * @return mixed
     */
    public function getCoupon();

    /**
     * @return mixed
     */
    public function getAddCoupon();

    /**
     * @return mixed
     */
    public function getCouponOption();

    /**
     * @return mixed
     */
    public function getExpire();

    /**
     * @return mixed
     */
    public function getDiscountType();

    /**
     * @return mixed
     */
    public function getDiscount();

    /**
     * @return mixed
     */
    public function getCouponLabel();


    /**
     * @param $id
     * @return mixed
     */
    public function setId($id);

    /**
     * @param $enable
     * @return mixed
     */
    public function setEnable($enable);

    /**
     * @param $title
     * @return mixed
     */
    public function setTitle($title);

    /**
     * @param $description
     * @return mixed
     */
    public function setDescription($description);

    /**
     * @param $template
     * @return mixed
     */
    public function setTemplate($template);

    /**
     * @param $store
     * @return mixed
     */
    public function setStore($store);

    /**
     * @param $customer_group
     * @return mixed
     */
    public function setCustomerGroup($customer_group);

    /**
     * @param $coupon
     * @return mixed
     */
    public function setCoupon($coupon);

    /**
     * @param $add_coupon
     * @return mixed
     */
    public function setAddCoupon($add_coupon);

    /**
     * @param $coupon_option
     * @return mixed
     */
    public function setCouponOption($coupon_option);

    /**
     * @param $expire
     * @return mixed
     */
    public function setExpire($expire);

    /**
     * @param $discount_type
     * @return mixed
     */
    public function setDiscountType($discount_type);

    /**
     * @param $discount
     * @return mixed
     */
    public function setDiscount($discount);

    /**
     * @param $coupon_label
     * @return mixed
     */
    public function setCouponLabel($coupon_label);

}
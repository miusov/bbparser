<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
namespace Webinse\AbandonedCart\Api\Data;

interface BlackListInterface
{
    const ID                    = 'entity_id';
    const CUSTOMER_EMAIL        = 'customer_email';

    /**
     * Get entity id.
     *
     * @return int
     */
    public function getId();

    /**
     * Get customer email.
     *
     * @return string
     */
    public function getCustomerEmail();

    /**
     * Set entity id.
     *
     * @param int $id
     * @return $this
     */
    public function setId($id);

    /**
     * Set customer email.
     *
     * @param string $customer_email
     * @return $this
     */
    public function setCustomerEmail($customer_email);

}
<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
namespace Webinse\AbandonedCart\Api\Data;

interface EmailLogInterface
{
    const ID                    = 'entity_id';
    const STATUS                = 'status';
    const QUANTITY              = 'quantity';
    const COUPON                = 'coupon';
    const CUSTOMER_FIRST_NAME   = 'customer_first_name';
    const CUSTOMER_LAST_NAME    = 'customer_last_name';
    const CUSTOMER_EMAIL        = 'customer_email';
    const RECOVERED_AT          = 'recovered_at';
    const SENT_AT               = 'sent_at';
    const ABANDONED_AT          = 'abandoned_at';

    /**
     * Get entity id.
     *
     * @return int
     */
    public function getId();

    /**
     * Get status.
     *
     * @return string
     */
    public function getStatus();


    /**
     * @return string
     */
    public function getQuantity();


    /**
     * @return string
     */
    public function getCoupon();

    /**
     * Get customer first name.
     *
     * @return string
     */
    public function getCustomerFirstName();

    /**
     * Get customer last name.
     *
     * @return string
     */
    public function getCustomerLastName();

    /**
     * Get customer email.
     *
     * @return string
     */
    public function getCustomerEmail();

    /**
     * Get recovered at.
     *
     * @return string
     */
    public function getRecoveredAt();

    /**
     * Get sent at.
     *
     * @return string
     */
    public function getSentAt();

    /**
     * Get abandoned at.
     *
     * @return string
     */
    public function getAbandonedAt();

    /**
     * Set entity id.
     *
     * @param int $id
     * @return $this
     */
    public function setId($id);

    /**
     * Set status.
     *
     * @param int $status
     * @return $this
     */
    public function setStatus($status);

    /**
     * @param $quantity
     * @return $this
     */
    public function setQuantity($quantity);

    /**
     * @param $coupon
     * @return $this
     */
    public function setCoupon($coupon);

    /**
     * Set customer first name.
     *
     * @param string $customer_first_name
     * @return $this
     */
    public function setCustomerFirstName($customer_first_name);

    /**
     * Set customer last name.
     *
     * @param string $customer_last_name
     * @return $this
     */
    public function setCustomerLastName($customer_last_name);

    /**
     * Set customer email.
     *
     * @param string $customer_email
     * @return $this
     */
    public function setCustomerEmail($customer_email);

    /**
     * Set recovered at.
     *
     * @param string $recovered_at
     * @return $this
     */
    public function setRecoveredAt($recovered_at);

    /**
     * Set sent at.
     *
     * @param string $sent_at
     * @return $this
     */
    public function setSentAt($sent_at);

    /**
     * Set abandoned at.
     *
     * @param string $abandoned_at
     * @return $this
     */
    public function setAbandonedAt($abandoned_at);
}
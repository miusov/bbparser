<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
namespace Webinse\AbandonedCart\Block\Adminhtml\System\Config;

class SendingHours implements \Magento\Framework\Data\OptionSourceInterface
{

    public function toOptionArray()
    {
        return [
            ['label' => '1:00', 'value' => '0 * * * *'],
            ['label' => '2:00', 'value' => '0 */2 * * *'],
            ['label' => '3:00', 'value' => '0 */3 * * *'],
            ['label' => '4:00', 'value' => '0 */4 * * *'],
            ['label' => '5:00', 'value' => '0 */5 * * *'],
            ['label' => '6:00', 'value' => '0 */6 * * *'],
            ['label' => '7:00', 'value' => '0 */7 * * *'],
            ['label' => '8:00', 'value' => '0 */8 * * *'],
            ['label' => '9:00', 'value' => '0 */9 * * *'],
            ['label' => '10:00', 'value' => '0 */10 * * *'],
            ['label' => '11:00', 'value' => '0 */11 * * *'],
            ['label' => '12:00', 'value' => '0 */12 * * *'],
            ['label' => '13:00', 'value' => '0 */13 * * *'],
            ['label' => '14:00', 'value' => '0 */14 * * *'],
            ['label' => '15:00', 'value' => '0 */15 * * *'],
            ['label' => '16:00', 'value' => '0 */16 * * *'],
            ['label' => '17:00', 'value' => '0 */17 * * *'],
            ['label' => '18:00', 'value' => '0 */18 * * *'],
            ['label' => '19:00', 'value' => '0 */19 * * *'],
            ['label' => '20:00', 'value' => '0 */20 * * *'],
            ['label' => '21:00', 'value' => '0 */21 * * *'],
            ['label' => '22:00', 'value' => '0 */22 * * *'],
            ['label' => '23:00', 'value' => '0 */23 * * *'],
            ['label' => '24:00', 'value' => '0 0 * * *']
        ];
    }
}
<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
namespace Webinse\AbandonedCart\Block\Adminhtml\System\Config;

use Magento\Email\Model\ResourceModel\Template\CollectionFactory;


class EmailTemplates extends \Magento\Framework\DataObject implements \Magento\Framework\Option\ArrayInterface
{


    protected $_templatesFactory;

    public function __construct(
        CollectionFactory $templatesFactory,
        array $data = []
    )
    {
        parent::__construct($data);
        $this->_templatesFactory = $templatesFactory;
    }

    public function toOptionArray()
    {
        $collection = $this->_templatesFactory->create();
        $collection->getData();

        $arr = [];
        foreach ($collection as $template)
        {
            $arr[] = ['label' => $template['template_code'], 'value' => $template['template_id']];
        }
        return $arr;
    }
}
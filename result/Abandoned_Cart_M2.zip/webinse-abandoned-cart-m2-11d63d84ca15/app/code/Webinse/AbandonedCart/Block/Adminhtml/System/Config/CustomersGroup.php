<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
namespace Webinse\AbandonedCart\Block\Adminhtml\System\Config;

use Magento\Customer\Model\ResourceModel\Group\CollectionFactory;


class CustomersGroup extends \Magento\Framework\DataObject implements \Magento\Framework\Option\ArrayInterface
{
    protected $_groupFactory;

    public function __construct(
        CollectionFactory $groupFactory,
        array $data = []
    )
    {
        parent::__construct($data);
        $this->_groupFactory = $groupFactory;
    }

    public function toOptionArray()
    {
        $collection = $this->_groupFactory->create();
        $collection->getData();

        $arr = [];
        foreach ($collection as $group)
        {
            $arr[] = ['label' => $group['customer_group_code'], 'value' => $group['customer_group_id']];
        }
        return $arr;
    }
}
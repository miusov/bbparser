<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
namespace Webinse\AbandonedCart\Block\Adminhtml\System\Config;

use Magento\Store\Model\ResourceModel\Group\CollectionFactory;


class Stores extends \Magento\Framework\DataObject implements \Magento\Framework\Option\ArrayInterface
{
    protected $_storesFactory;

    public function __construct(
        CollectionFactory $templatesFactory,
        array $data = []
    )
    {
        parent::__construct($data);
        $this->_storesFactory = $templatesFactory;
    }

    public function toOptionArray()
    {
        $collection = $this->_storesFactory->create();
        $collection->getData();

        $arr = [];
        foreach ($collection as $website)
        {
            $arr[] = ['label' => $website['name'], 'value' => $website['website_id']];
        }
        return $arr;
    }
}
<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */

namespace Webinse\AbandonedCart\Controller\Adminhtml\Config;

use Magento\Backend\App\Action;
use Magento\Framework\Mail\Template\TransportBuilder;
use Webinse\AbandonedCart\Model\Config;
use Magento\Store\Model\StoreManagerInterface;

class TestEmail extends Action
{
    private   $transportBuilder;
    protected $_config;
    protected $_storeManager;

    public function __construct(
        Action\Context $context,
        Config $config,
        StoreManagerInterface $storeManager,
        TransportBuilder $transportBuilder
    )
    {
        $this->transportBuilder = $transportBuilder;
        $this->_config          = $config;
        $this->_storeManager    = $storeManager;
        parent::__construct($context);
    }

    public function execute()
    {

        $config     = $this->_config;
        $email      = $config->getSenderEmail();
        $store_id   = $this->_storeManager->getStore()->getId();
        if (isset ( $email ) )
        {
            $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $store_id);
            $from = array('email' => $config->getSenderEmail(), 'name' => $config->getSenderName());
            $templateVars = array(
                'testMessage' => 'testMessage'
            );

            $transport = $this->transportBuilder->setTemplateIdentifier(1)
                ->setTemplateOptions($templateOptions)
                ->setTemplateVars($templateVars)
                ->setFrom($from)
                ->addTo($email)
                ->getTransport();
            $transport->sendMessage();

            $this->messageManager->addSuccessMessage('Test message sent, please check '.$email);
            $this->_redirect('adminhtml/system_config/edit/section/abandonedcart');
        }
        else
        {
            $this->messageManager->addErrorMessage('Fill in field "Email address" and Save Configuration');
            $this->_redirect('adminhtml/system_config/edit/section/abandonedcart');
        }

    }
}
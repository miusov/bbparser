<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */

namespace Webinse\AbandonedCart\Controller\Adminhtml\CartRules;
use Magento\Backend\App\Action;
use Webinse\AbandonedCart\Model\CartRules;

class Disable extends Action
{

    protected $_model;
    /**
     * Edit constructor.
     * @param Action\Context $context
     * @param CartRules $model
     */
    public function __construct(
        Action\Context $context,
        CartRules $model
    )
    {
        parent::__construct($context);
        $this->_model = $model;
    }

    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        $this->disable($id);
        $this->messageManager->addSuccessMessage(__('Rule with ID = %1 disable!', $id));
        $this->_redirect('*/*/index');
    }

    public function disable($id)
    {
        $model = $this->_model;
        $model->load($id);

        if ($model->getId()) {
            $model->setData('enable',0);
            $model->save();
        } else {
            $this->messageManager->addErrorMessage(__('Rule with ID = %1 not found.',$id));
            $this->_redirect('*/*/index');
        }
    }
}
<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */

namespace Webinse\AbandonedCart\Controller\Adminhtml\ImportBlackList;

use Magento\Backend\App\Action;
use Magento\Framework\File\Csv;
use Webinse\AbandonedCart\Model\BlackList;
use Webinse\AbandonedCart\Model\ResourceModel\BlackList\CollectionFactory;
use Magento\Framework\App\Filesystem\DirectoryList;

class Import extends Action
{
    /**
     * @var Csv
     */
    protected $_csv;
    /**
     * @var BlackList
     */
    protected $_blackListModel;
    /**
     * @var CollectionFactory
     */
    protected $_blackListCollection;
    /**
     * @var DirectoryList
     */
    protected $_directoryList;

    /**
     * Import constructor.
     * @param Action\Context $context
     * @param Csv $csv
     * @param BlackList $blackListModel
     * @param DirectoryList $directoryList
     * @param CollectionFactory $blackListCollectionFactory
     */
    public function __construct(
        Action\Context $context,
        Csv $csv,
        BlackList $blackListModel,
        DirectoryList $directoryList,
        CollectionFactory $blackListCollectionFactory
    ) {
        $this->_csv                 = $csv;
        $this->_blackListModel      = $blackListModel;
        $this->_blackListCollection = $blackListCollectionFactory;
        $this->_directoryList       = $directoryList;
        parent::__construct($context);
    }

    /**
     * @return $this|\Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     * @throws \Exception
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $black_list = $this->_blackListModel;

        /**
         * Get Black List and filter only email
         */
        $black_list_collection = $this->_blackListCollection->create();
        $data = $black_list_collection->getData();
        $black_list_emails = [];

        foreach ($data as $item)
        {
            $black_list_emails[] = $item['customer_email'];
        }

        $tmpDir = $this->_directoryList->getPath('tmp');
        $file = $tmpDir . '/datasheet-blackList.csv';

        if (!isset($file)) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Invalid file upload attempt.'));
        }

        $csv = $this->_csv;
        $csv->setDelimiter(';');
        $csvData = $csv->getData($file);

        foreach ($csvData as $row => $data) {
            if ( count($data) == 1 )
            {
                if ( !in_array($data[0],$black_list_emails) )
                {
                    $black_list->setData([
                        'customer_email' => $data[0]
                    ])->save();
                }
            }
            else{
                $this->messageManager->addError('The list of e-mails should be in one column!');
                return $resultRedirect->setPath('*/*/index');
            }
        }
        $this->messageManager->addSuccess('Import Successful!');
        return $resultRedirect->setPath('webinse_abandonedcart/blackList/index');
    }
}
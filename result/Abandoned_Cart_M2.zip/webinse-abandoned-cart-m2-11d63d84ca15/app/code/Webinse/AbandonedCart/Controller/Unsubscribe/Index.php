<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */

namespace Webinse\AbandonedCart\Controller\Unsubscribe;

use Magento\Framework\App\Action;
use Webinse\AbandonedCart\Model\BlackList;
use Magento\Customer\Model\Customer;
use Webinse\AbandonedCart\Model\ResourceModel\BlackList\CollectionFactory;

class Index extends Action\Action
{
    protected $_black_list_model;
    protected $_customers;
    protected $_black_list_collection;
    protected $_pageFactory;

    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        BlackList $blackList,
        CollectionFactory $blackListCollection,
        Customer $customers
    )
    {
        $this->_pageFactory = $pageFactory;
        $this->_black_list_model    = $blackList;
        $this->_black_list_collection  = $blackListCollection;
        $this->_customers           = $customers;
        return parent::__construct($context);
    }

    public function getCustomer($customerId)
    {
        return $this->_customers->load($customerId);
    }

    public function execute()
    {
        $blackList = $this->_black_list_model;

        $id = $this->getRequest()->getParam('cid');
        $token = $this->getRequest()->getParam('token');
        $decode_token = base64_decode($token);
        $customer = $this->getCustomer($id);

        $black_list_collection = $this->_black_list_collection->create();
        $black_list_collection->addFieldToFilter('customer_email',["eq" => $customer->getEmail()]);
        $count = count($black_list_collection);

        if ($decode_token == 'prefix_'.$customer->getEmail())
        {
            if ($count == 0)
            {
                $blackList->setCustomerEmail($customer->getEmail());
                $blackList->save();
            }
            return $this->_pageFactory->create();
        }
    }
}
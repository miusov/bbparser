<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */

namespace Webinse\AbandonedCart\Controller\Abandoned;

use Magento\Framework\App\Action;
use Magento\Quote\Model\ResourceModel\Quote\CollectionFactory as Quote;
use Webinse\AbandonedCart\Model\CartCheckout;
use Webinse\AbandonedCart\Model\ResourceModel\CartCheckout\CollectionFactory as CartCheckoutCollection;
use Magento\Framework\Controller\Result\JsonFactory;

class Checkout extends Action\Action
{
    public $_resultJsonFactory;
    protected $_qoute;
    protected $_cartCheckoutModel;
    protected $_cartCheckoutCollection;

    public function __construct(
        Action\Context $context,
        JsonFactory $resultJsonFactory,
        CartCheckout $cartcheckout,
        CartCheckoutCollection $cartCheckoutCollection,
        Quote $quote
    )
    {
        $this->_resultJsonFactory       = $resultJsonFactory;
        $this->_qoute                   = $quote;
        $this->_cartCheckoutModel       = $cartcheckout;
        $this->_cartCheckoutCollection  = $cartCheckoutCollection;
        return parent::__construct($context);
    }


    public function execute()
    {
        if ($this->getRequest()->isAjax())
        {
            $ip = $this->getRequest()->getParam('ip');
            $email = $this->getRequest()->getParam('email');
            $first_name = $this->getRequest()->getParam('first_name');
            $last_name = $this->getRequest()->getParam('last_name');

            $quote_collection = $this->_qoute->create()
                ->addFieldToFilter('remote_ip',["eq" => $ip])
                ->getLastItem()
                ->getData();

            $cart_checkout_collection = $this->_cartCheckoutCollection->create()
                ->addFieldToFilter('email',["eq" => $email])
                ->getLastItem()
                ->getData();

            $checkout_model = $this->_cartCheckoutModel;
            if (isset($cart_checkout_collection['email']))
            {
                $checkout_model->load($cart_checkout_collection['entity_id']);
            }
            if (isset($first_name)) $checkout_model->setData('first_name',$quote_collection['customer_firstname']);
            if (isset($last_name)) $checkout_model->setData('last_name',$quote_collection['customer_lastname']);
            $checkout_model->setData('customer_id',$quote_collection['customer_id']);
            $checkout_model->setData('grand_total',$quote_collection['grand_total']);
            $checkout_model->setData('items_count',$quote_collection['items_count']);
            $checkout_model->setData('created_at',$quote_collection['created_at']);
            $checkout_model->setData('updated_at',$quote_collection['updated_at']);
            $checkout_model->setData('email',$email);
            $checkout_model->setData('customer_is_guest',1);
            $checkout_model->setData('customer_group_id',0);
            $checkout_model->save();


            $result = $this->_resultJsonFactory->create();
            $test=['Request' => 'OK'];
            return $result->setData($test);
        }
        return 'AJAX ERROR';
    }
}
<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */

namespace Webinse\AbandonedCart\Controller\Abandoned;

use Magento\Framework\App\Action;
use Magento\Customer\Model\Customer;
use Magento\Framework\View\Result\PageFactory;
use Magento\Quote\Model\Quote;
use Magento\Customer\Model\Session;
use Magento\Checkout\Model\Session as Checkout;
use Webinse\AbandonedCart\Model\ResourceModel\EmailLog\CollectionFactory;
use Webinse\AbandonedCart\Model\EmailLog;

class Loadquote extends Action\Action
{
    protected $_customers;
    protected $_resultPageFactory;
    protected $_quote;
    protected $_session;
    protected $_checkout;
    protected $_emailLogCollectionFactory;
    protected $_emailLogModel;

    public function __construct(
        Action\Context $context,
        PageFactory $resultPageFactory,
        Quote $quote,
        Session $session,
        Checkout $checkout,
        CollectionFactory $emailLogCollectionFactory,
        EmailLog $emailLogModel,
        Customer $customers
    )
    {
        $this->_customers                   = $customers;
        $this->_resultPageFactory           = $resultPageFactory;
        $this->_quote                       = $quote;
        $this->_session                     = $session;
        $this->_checkout                    = $checkout;
        $this->_emailLogCollectionFactory   = $emailLogCollectionFactory;
        $this->_emailLogModel               = $emailLogModel;
        return parent::__construct($context);
    }

    public function getCustomer($customerId)
    {
        return $this->_customers->load($customerId);
    }
    protected function _getCustomerSession()
    {
        return $this->_session;
    }
    protected function _getCheckoutSession()
    {
        return $this->_checkout;
    }

    public function execute()
    {

        $quote_id = (int) $this->getRequest()->getParam('id', false);
        $customer_id = (int) $this->getRequest()->getParam('cid', false);
        $token = $this->getRequest()->getParam('token', false);
        $decode_token = base64_decode($token);
        $customer = $this->getCustomer($customer_id);
        $email_log_factory = $this->_emailLogCollectionFactory->create()
            ->addFieldToFilter('customer_email', ["eq" => $customer->getEmail()]);
        $email_log_id = $email_log_factory->getAllIds()[0];
        $email_log_model = $this->_emailLogModel;
        $email_log_model->load($email_log_id);


        if($quote_id)
        {
            $quote = $this->_quote->load($quote_id);

            if(!$decode_token || $decode_token != 'prefix_'.$customer->getEmail())
            {
                $this->messageManager->addNotice("Invalid token");
                $this->_redirect('customer/account/login');
            }
            else
            {
                $quote->save();
                if(!$quote->getCustomerId())
                {
                    $this->_getCheckoutSession()->setQuoteId($quote->getId());
                }
                if($quote->getCustomerId())
                {
                    $customerSession = $this->_getCustomerSession();
                    if(!$customerSession->isLoggedIn())
                    {
                        $customerSession->loginById($quote->getCustomerId());
                    }
                    $email_log_model->setData('recovered_at',date('Y-m-d H:i:s'));
                    $email_log_model->save();
                    $this->_redirect('checkout/cart');
                }
            }

        }

    }
}
<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_AbandonedCart
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */

namespace Webinse\AbandonedCart\Controller\Adminhtml\EmailLog;

use Magento\Backend\App\Action;
use Webinse\AbandonedCart\Model\EmailLog;
use Magento\Store\Model\StoreManager;
use Webinse\AbandonedCart\Model\Config;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Controller\ResultFactory;
use Webinse\AbandonedCart\Model\Cron;
use Magento\Reports\Model\ResourceModel\Quote\CollectionFactory as QuoteCollectionFactory;
use Webinse\AbandonedCart\Model\ResourceModel\EmailLog\CollectionFactory as EmailLogCollectionFactory;
use Webinse\AbandonedCart\Model\ResourceModel\BlackList\CollectionFactory as BlackListCollectionFactory;
use Webinse\AbandonedCart\Model\ResourceModel\CartCheckout\CollectionFactory as CartCheckoutFactory;


class Send extends Action
{

    protected $_emailLogModel;
    protected $_storeManager;
    protected $_config;
    protected $_emailLogCollectionFactory;
    protected $_blackListCollectionFactory;
    protected $_abandonedCartCollectionFactory;
    private   $transportBuilder;
    protected $_cron;
    protected $_cartCheckoutFacrory;

    public function __construct(
        Action\Context $context,
        EmailLog $model,
        Config $config,
        Cron $cron,
        QuoteCollectionFactory $abandonedCartCollectionFactory,
        EmailLogCollectionFactory $emailLogCollectionFactory,
        BlackListCollectionFactory $blackListCollectionFactory,
        StoreManager $storeManager,
        CartCheckoutFactory $cartCheckoutFactory,
        TransportBuilder $transportBuilder
    )
    {
        $this->_emailLogModel                   = $model;
        $this->_storeManager                    = $storeManager;
        $this->_config                          = $config;
        $this->_emailLogCollectionFactory       = $emailLogCollectionFactory;
        $this->_blackListCollectionFactory      = $blackListCollectionFactory;
        $this->_abandonedCartCollectionFactory  = $abandonedCartCollectionFactory;
        $this->transportBuilder                 = $transportBuilder;
        $this->_cron                            = $cron;
        $this->_cartCheckoutFacrory             = $cartCheckoutFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $id = $this->getRequest()->getParam('id');

        $this->send($id);

        $this->messageManager->addSuccess(__('Message(s) sent!'));
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('*/*/index');
    }

    public function send($id)
    {
        $config                 = $this->_config;
        $store_id               = $this->_storeManager->getStore()->getId();
        $email_log              = $this->_emailLogModel;
        $createCoupon           = $config->getCreateYesNo();
        $numEmailCoupon         = $config->getAddCoupon();
        $abandoned_cart         = $this->getAbandonedCart($id);

        $email_log_model = $this->_emailLogModel;
        $email_log_model->load($id);

        $black_list_collection = $this->_blackListCollectionFactory->create();
        $data = $black_list_collection->getData();
        $black_list_emails = [];

        foreach ($data as $item)
        {
            $black_list_emails[] = $item['customer_email'];
        }

        $emailLogCollection = $this->_emailLogCollectionFactory->create()
            ->addFieldToFilter('customer_email', ["eq" => $email_log_model->getCustomerEmail()]);
        $data = $emailLogCollection->getData();
        $email_log_emails = [];
        $email_log_quantity = '';
        $email_log_id ='';

        foreach ($data as $item)
        {
            $email_log_id = $item['entity_id'];
            $email_log_emails[] = $item['customer_email'];
            $email_log_quantity = (int)$item['quantity'];
        }

        if( !in_array($email_log_model->getCustomerEmail(),$black_list_emails) )
        {

            $templateVars = [
                'customerId'        => $abandoned_cart['customer_id'],
                'token'             => base64_encode('prefix_'.$abandoned_cart['email']),
                'baseURL'           => $this->_storeManager->getStore()->getBaseUrl(),
                'firstName'         => $abandoned_cart['first_name'],
                'lastName'          => $abandoned_cart['last_name'],
                'customerEmail'     => $abandoned_cart['email'],
                'grandTotal'        => $abandoned_cart['grand_total'],
                'itemsCount'        => $abandoned_cart['items_count'],
                'updatedAt'         => $abandoned_cart['updated_at']
            ];

            if($createCoupon == 1 && $email_log_quantity >= $numEmailCoupon)
            {
                $coupon = $this->_cron->_createNewCoupon($store_id,$email_log_model->getCustomerEmail());
                $email_log->load($email_log_id);
                $email_log->setData('coupon','YES')->save();
                $templateVars += [
                    'couponId'          => $coupon[0],
                    'couponDiscount'    => $coupon[1],
                    'couponToDate'      => $coupon[2]
                ];
            }

            $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $store_id);
            $from = array('email' => $this->_config->getSenderEmail(), 'name' => $config->getSenderName());
            $transport = $this->transportBuilder->setTemplateIdentifier($this->_config->getEmailTemplateId())
                ->setTemplateOptions($templateOptions)
                ->setTemplateVars($templateVars)
                ->setFrom($from)
                ->addTo($abandoned_cart['email'])
                ->getTransport();
            $transport->sendMessage();

            if( in_array($abandoned_cart['email'],$email_log_emails) )
            {
                $email_log_quantity ++;

                $email_log->load($email_log_id);
                $email_log->setData('status','Sent');
                $email_log->setData('quantity',$email_log_quantity);
                $email_log->setData('customer_first_name',$abandoned_cart['first_name']);
                $email_log->setData('customer_last_name',$abandoned_cart['last_name']);
                $email_log->setData('customer_email',$abandoned_cart['email']);
                $email_log->setData('sent_at',date('Y-m-d H:i:s'));
                $email_log->setData('abandoned_at',$abandoned_cart['updated_at']);
                $email_log->save();

                unset($email_log_emails);
                sleep(2);
            }
            else
            {
                $email_log->setData([
                    'status' => 'Sent',
                    'quantity' => 1,
                    'customer_first_name'   => $abandoned_cart['first_name'],
                    'customer_last_name'    => $abandoned_cart['last_name'],
                    'customer_email'        => $abandoned_cart['email'],
                    'sent_at'               => date('Y-m-d H:i:s'),
                    'abandoned_at'          => $abandoned_cart['updated_at']
                ])->save();

                unset($email_log_emails);
            }
        }
    }

    protected function getAbandonedCart($id)
    {
        /**
         * Get Abandoned Cart
         */
        $email_log_model = $this->_emailLogModel;
        $email_log_model->load($id);

        $abandoned_cart_collection = $this->_abandonedCartCollectionFactory->create();
        $abandoned_cart_collection->prepareForAbandonedReport([$this->_storeManager->getStore()->getId()]);
        $abandoned_cart_collection->addFieldToFilter('customer_email',$email_log_model->getCustomerEmail());
        $ac_rows = $abandoned_cart_collection->load();

        if (count($ac_rows)>0)
        {
            $carts = $ac_rows->getItems();
            $cartInfo = [];
            $cartsInfo = [];
            foreach ($carts as $cart)
            {
                if ($this->_cron->dateInterval(date('Y-m-d H:i:s'),$cart->getUpdateAt()) >= $this->_config->getMinDays())
                {
                    $cartInfo['customer_id']        = $cart->getCustomerId();
                    $cartInfo['first_name']         = $cart->getCustomerFirstname();
                    $cartInfo['last_name']          = $cart->getCustomerLastname();
                    $cartInfo['email']              = $cart->getCustomerEmail();
                    $cartInfo['grand_total']        = $cart->getGrandTotal();
                    $cartInfo['items_count']        = $cart->getItemsCount();
                    $cartInfo['updated_at']         = $cart->getUpdatedAt();
                    $cartInfo['customer_is_guest']  = $cart->getCustomerIsGuest();
                    $cartsInfo[] = $cartInfo;
                }
            }
            return $cartsInfo[0];
        }
        else {
            $cart_checkaut = $this->_cartCheckoutFacrory->create();
            $cart_checkaut->addFieldToFilter('email', $email_log_model->getCustomerEmail());
            $cc_rows = $cart_checkaut->load();
            $carts = $cc_rows->getItems();
            $cartInfo = [];
            $cartsInfo = [];
            foreach ($carts as $cart)
            {
                if ($this->_cron->dateInterval(date('Y-m-d H:i:s'),$cart->getUpdateAt()) >= $this->_config->getMinDays())
                {
                    $cartInfo['customer_id']        = $cart->getCustomerId();
                    $cartInfo['first_name']         = $cart->getFirstName();
                    $cartInfo['last_name']          = $cart->getLastName();
                    $cartInfo['email']              = $cart->getEmail();
                    $cartInfo['grand_total']        = $cart->getGrandTotal();
                    $cartInfo['items_count']        = $cart->getItemsCount();
                    $cartInfo['updated_at']         = $cart->getUpdatedAt();
                    $cartInfo['customer_is_guest']  = $cart->getCustomerIsGuest();
                    $cartsInfo[] = $cartInfo;
                }
            }
            return $cartsInfo[0];
        }
    }
}
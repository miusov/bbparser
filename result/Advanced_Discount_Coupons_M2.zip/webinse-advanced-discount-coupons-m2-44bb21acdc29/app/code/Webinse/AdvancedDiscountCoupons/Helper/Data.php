<?php

/**
 * Webinse
 *
 * PHP Version 5.6.23
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */
/**
 * Helper Class for getting data from sections
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */

namespace Webinse\AdvancedDiscountCoupons\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;

class Data extends AbstractHelper
{
    /**
     * Data constructor.
     * @param Context $context
     */
    public function __construct(Context $context)
    {
        parent::__construct($context);
    }

    /**
     * @param $path
     * @return mixed
     */
    public function _getConfig($path)
    {
        return $this->scopeConfig
            ->getValue("advanceddiscountcoupons/{$path}", \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getSubject()
    {
        return $this->_getConfig('general_settings/subject_email');
    }

    public function getSenderName()
    {
        return $this->_getConfig('general_settings/sender_name');
    }

    public function getSenderEmail()
    {
        return $this->_getConfig('general_settings/sender_email');
    }

    public function isModuleCustomerBirthdayEnable()
    {
        return $this->_getConfig('customer_birthday/enable');
    }

    public function sentCoupBeforeBirthday()
    {
        return $this->_getConfig('customer_birthday/send_coupon_after');
    }

    public function discountTypeBirthday()
    {
        return $this->_getConfig('customer_birthday/discount_type');
    }

    public function discountAmountBirthday()
    {
        return $this->_getConfig('customer_birthday/discount_amount');
    }

    public function expireDayBirthday()
    {
        return $this->_getConfig('customer_birthday/expire_days');
    }

    public function customerGroupBirthday()
    {
        return $this->_getConfig('customer_birthday/customer_group');
    }
    public function storeBirthday()
    {
        return $this->_getConfig('customer_birthday/store');
    }

    public function isModulePerDayEnable()
    {
        return $this->_getConfig('per_day_active_customer/enable');
    }

    public function numberOfRegisteredDays()
    {
        return $this->_getConfig('per_day_active_customer/number_of_registered_days');
    }

    public function discountTypeActivity()
    {
        return $this->_getConfig('per_day_active_customer/discount_type');
    }

    public function discountAmountActivity()
    {
        return $this->_getConfig('per_day_active_customer/discount_amount');
    }

    public function expireDayActivity()
    {
        return $this->_getConfig('per_day_active_customer/expire_days');
    }

    public function customerGroupActivity()
    {
        return $this->_getConfig('per_day_active_customer/customer_group');
    }

    public function storeActivity()
    {
        return $this->_getConfig('per_day_active_customer/store');
    }

    public function isModuleOrderEnable()
    {
        return $this->_getConfig('order_count/enable');
    }

    public function numberOfOrders()
    {
        return $this->_getConfig('order_count/number_of_orders');
    }

    public function discountTypeOrder()
    {
        return $this->_getConfig('order_count/discount_type');
    }

    public function discountAmountOrder()
    {
        return $this->_getConfig('order_count/discount_amount');
    }

    public function expireDayOrder()
    {
        return $this->_getConfig('order_count/expire_days');
    }

    public function customerGroupOrder()
    {
        return $this->_getConfig('order_count/customer_group');
    }

    public function storeOrder()
    {
        return $this->_getConfig('order_count/store');
    }

    public function isModuleNotActivityEnable()
    {
        return $this->_getConfig('not_active_customer/enable');
    }

    public function dayNotActivity()
    {
        return $this->_getConfig('not_active_customer/day_not_activity');
    }

    public function discountTypeNotActivity()
    {
        return $this->_getConfig('not_active_customer/discount_type');
    }

    public function discountAmountNotActivity()
    {
        return $this->_getConfig('not_active_customer/discount_amount');
    }

    public function expireDayNotActivity()
    {
        return $this->_getConfig('not_active_customer/expire_days');
    }

    public function customerGroupNotActivity()
    {
        return $this->_getConfig('not_active_customer/customer_group');
    }

    public function storeNotActivity()
    {
        return $this->_getConfig('not_active_customer/store');
    }

    public function isModuleHolidayEnable()
    {
        return $this->_getConfig('coupon_holidays/enable');
    }

    public function nameHoliday()
    {
        return $this->_getConfig('coupon_holidays/holiday_name');
    }

    public function startDateHoliday()
    {
        return $this->_getConfig('coupon_holidays/start_date');
    }

    public function discountTypeHoliday()
    {
        return $this->_getConfig('coupon_holidays/discount_type');
    }

    public function discountAmountHoliday()
    {
        return $this->_getConfig('coupon_holidays/discount_amount');
    }

    public function expireDayHoliday()
    {
        return $this->_getConfig('coupon_holidays/expire_days');
    }

    public function customerGroupHoliday()
    {
        return $this->_getConfig('coupon_holidays/customer_group');
    }

    public function storeHoliday()
    {
        return $this->_getConfig('coupon_holidays/store');
    }

    public function isModuleRegisterEnable()
    {
        return $this->_getConfig('customer_registration/enable');
    }

    public function discountTypeRegister()
    {
        return $this->_getConfig('customer_registration/discount_type');
    }

    public function discountAmountRegister()
    {
        return $this->_getConfig('customer_registration/discount_amount');
    }

    public function expireDayRegister()
    {
        return $this->_getConfig('customer_registration/expire_days');
    }

    public function customerGroupRegister()
    {
        return $this->_getConfig('customer_registration/customer_group');
    }
    public function storeRegister()
    {
        return $this->_getConfig('customer_registration/store');
    }
}
<?php

/**
 * Webinse
 *
 * PHP Version 5.6.23
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */
/**
 * Button for configuration page
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */

namespace Webinse\AdvancedDiscountCoupons\Block\Adminhtml\Config\System;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;

class Button extends Field
{
    protected function _getElementHtml(AbstractElement $element)
    {
        $url = $this->getUrl('advanceddiscountcoupon/holidaycoupon/index');

        $button = $this->getLayout()->createBlock('Magento\Backend\Block\Widget\Button')
            ->setData([
                'id' => 'rebuild_button',
                'label' => __('Apply new coupons by Holiday'),
                'class' => 'primary',
                'onclick' => "window.location='{$url}';",
            ]);

        return $button->toHtml();
    }
}

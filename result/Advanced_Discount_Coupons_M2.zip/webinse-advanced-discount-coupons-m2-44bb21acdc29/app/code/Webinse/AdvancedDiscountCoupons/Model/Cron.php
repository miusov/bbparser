<?php

/**
 * Webinse
 *
 * PHP Version 5.6.23
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */
/**
 * Cron for creation all rulse coupon
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */

namespace Webinse\AdvancedDiscountCoupons\Model;

use Magento\Customer\Model\ResourceModel\Customer\CollectionFactory;
use Webinse\AdvancedDiscountCoupons\Helper\Data;
use Webinse\AdvancedDiscountCoupons\Model\Coupons;
use Magento\Customer\Model\LoggerFactory;

class Cron
{
    /**
     * @var CollectionFactory
     */
    protected $_collectionFactory;

    /**
     * @var Data
     */
    protected $_helper;

    /**
     * @var \Webinse\AdvancedDiscountCoupons\Model\Coupons
     */
    protected $_modelCoupon;

    /**
     * @var LoggerFactory
     */
    protected $_loggerFactory;

    /**
     * Cron constructor.
     * @param CollectionFactory $collectionFactory
     * @param Data $helper
     * @param \Webinse\AdvancedDiscountCoupons\Model\Coupons $modelCoupon
     * @param LoggerFactory $loggerFactory
     */
    public function __construct(
        CollectionFactory $collectionFactory,
        Data $helper,
        Coupons $modelCoupon,
        LoggerFactory $loggerFactory
    )
    {
        $this->_collectionFactory = $collectionFactory;
        $this->_helper = $helper;
        $this->_modelCoupon = $modelCoupon;
        $this->_loggerFactory = $loggerFactory;
    }

    public function couponBirthday()
    {
        $helper = $this->_helper;
        if ($helper->isModuleCustomerBirthdayEnable()) {
            $dob = array();
            $i=0;
            foreach ($this->_collectionFactory->create()->getItems() as $customer) {
                $allDob = $customer->getDob();
                if (date("m j", strtotime('-' . $helper->sentCoupBeforeBirthday() . ' day', strtotime($allDob))) == date("m j", time())) {
                    $a = $i++;
                    $dob[$a]['email'] = $customer->getEmail();
                    $dob[$a]['customer_name'] = $customer->getName();
                }
            }

            if (!empty(count($dob))) {

                $parameters = array(
                    'count' => count($dob),
                    'format' => 'alphanumeric',
                    'dash_every_x_characters' => 4,
                    'length' => 20
                );

                $sumDay = $helper->sentCoupBeforeBirthday() + $helper->expireDayBirthday();

                $coupon['name'] = 'Birthday Discount';
                $coupon['desc'] = 'Discount for birthday customer.';
                $coupon['start'] = date('Y-m-d', strtotime('+' . $helper->sentCoupBeforeBirthday() . 'day', time()));
                $coupon['end'] = date("Y-m-d", strtotime('+' . $sumDay . ' day', time()));
                $coupon['max_redemptions'] = 1;
                $coupon['discount_type'] = $helper->discountTypeBirthday();
                $coupon['discount_amount'] = $helper->discountAmountBirthday();
                $coupon['flag_is_free_shipping'] = 'no';
                $coupon['redemptions'] = 1;
                $coupon['website_id'] = $helper->storeBirthday();
                $coupon['customer_groups'] = $helper->customerGroupBirthday();
                $coupon['from_date'] = date("Y-m-d", strtotime('+' . $helper->sentCoupBeforeBirthday() . ' day', time()));
                $coupon['customer'] = $dob;

                $this->_modelCoupon->createCoupon($coupon, $parameters, 'birthday');
            }
        }
    }

    public function couponPerDayActivity()
    {
        $helper = $this->_helper;
        if ($helper->isModulePerDayEnable()) {
            $createdAtCount = array();
            $i = 0;
            foreach ($this->_collectionFactory->create()->getItems() as $customer) {
                $allCreated = $customer->getCreatedAt();
                if (date("m j", strtotime('+' . $helper->numberOfRegisteredDays() . ' day', strtotime($allCreated))) == date("m j", time())) {
                    $a = $i++;
                    $createdAtCount[$a]['customer_name'] = $customer->getName();
                    $createdAtCount[$a]['email'] = $customer->getEmail();
                }
            }

            if (!empty(count($createdAtCount))) {

                $parameters = array(
                    'count' => count($createdAtCount),
                    'format' => 'alphanumeric',
                    'dash_every_x_characters' => 4,
                    'length' => 20
                );

                $coupon['name'] = 'Per day Activity Customer';
                $coupon['desc'] = 'Discount for Per day Activity Customer.';
                $coupon['start'] = date("Y-m-d", time());
                $coupon['end'] = date("Y-m-d", strtotime('+' . $helper->expireDayActivity() . ' day', time()));
                $coupon['max_redemptions'] = 1;
                $coupon['discount_type'] = $helper->discountTypeActivity();
                $coupon['discount_amount'] = $helper->discountAmountActivity();
                $coupon['flag_is_free_shipping'] = 'no';
                $coupon['redemptions'] = 1;
                $coupon['website_id'] = $helper->storeBirthday();
                $coupon['customer_groups'] = $helper->customerGroupBirthday();
                $coupon['customer'] = $createdAtCount;

                $this->_modelCoupon->createCoupon($coupon, $parameters, 'per_day_activity');

            }
        }
    }

    // TODO: Remove in last commit
    /*public function couponOrderCount()
    {
        $helper = $this->_helper;
        if ($helper->isModuleOrderEnable()) {
            $order = $this->_orderCollectionFactory->create();

            if (!empty(count($order->getCollection()->addFieldToFilter('customer_id', 1)))) {

                $parameters = array(
                    'count' => 1,
                    'format' => 'alphanumeric',
                    'dash_every_x_characters' => 4,
                    'length' => 20
                );

                $coupon['name'] = 'Order Count Discount Coupon For Customer ';
                $coupon['desc'] = 'Discount for Per day Activity Customer.';
                $coupon['start'] = date("Y-m-d", time());
                $coupon['end'] = date("Y-m-d", strtotime('+' . $helper->expireDayOrder() . ' day', time()));
                $coupon['max_redemptions'] = 1;
                $coupon['discount_type'] = $helper->discountTypeOrder();
                $coupon['discount_amount'] = $helper->discountAmountOrder();
                $coupon['flag_is_free_shipping'] = 'no';
                $coupon['redemptions'] = 1;
                $coupon['website_id'] = $helper->storeOrder();
                $coupon['customer_groups'] = $helper->customerGroupOrder();

                $this->_modelCoupon->createCoupon($coupon, $parameters);
            }
        }
    }*/

    public function couponNotActivity()
    {
        $helper = $this->_helper;
        if ($helper->isModulePerDayEnable()) {
            $visitAdCount = array();
            $i = 0;
            foreach ($this->_collectionFactory->create()->getItems() as $customer) {
                //$i = 0;
                $lastVisitAt = $this->_loggerFactory->create()->get($customer->getId())->getLastVisitAt();
                if (date("m j", strtotime('+' . $helper->dayNotActivity() . ' day', strtotime($lastVisitAt))) == date("m j", time())) {
                    $a = $i++;
                    $visitAdCount[$a]['email'] = $customer->getEmail();
                    $visitAdCount[$a]['visit_date'] = $lastVisitAt;
                    $visitAdCount[$a]['customer_name'] = $customer->getName();
                }
            }

            if (!empty(count($visitAdCount))) {
                $parameters = array(
                    'count' => count($visitAdCount),
                    'format' => 'alphanumeric',
                    'dash_every_x_characters' => 4,
                    'length' => 20
                );

                $coupon['name'] = 'Not activity days';
                $coupon['desc'] = 'Not activity days.';
                $coupon['start'] = date("Y-m-d", time());
                $coupon['end'] = date("Y-m-d", strtotime('+' . $helper->expireDayNotActivity() . ' day', time()));
                $coupon['max_redemptions'] = 1;
                $coupon['discount_type'] = $helper->discountTypeNotActivity();
                $coupon['discount_amount'] = $helper->discountAmountNotActivity();
                $coupon['flag_is_free_shipping'] = 'no';
                $coupon['redemptions'] = 1;
                $coupon['website_id'] = $helper->storeNotActivity();
                $coupon['customer_groups'] = $helper->customerGroupNotActivity();
                $coupon['customer'] = $visitAdCount;

                $this->_modelCoupon->createCoupon($coupon, $parameters, 'not_activity');
            }
        }
    }
}
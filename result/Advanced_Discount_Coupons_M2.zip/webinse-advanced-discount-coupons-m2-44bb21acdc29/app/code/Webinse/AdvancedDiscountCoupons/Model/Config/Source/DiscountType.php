<?php

/**
 * Webinse
 *
 * PHP Version 5.6.23
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */
/**
 * Array for discount type in section
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */


namespace Webinse\AdvancedDiscountCoupons\Model\Config\Source;

class DiscountType implements \Magento\Framework\Option\ArrayInterface
{
    public function toOptionArray() {
        return [
            [
                'value' => 'by_percent',
                'label' => __('Percent of product price discount'),
            ],
            [
                'value' => 'by_fixed',
                'label' => __('Fixed amount discount'),
            ],
            [
                'value' => 'cart_fixed',
                'label' => __('Fixed amount discount for whole cart'),
            ]
        ];
    }

}
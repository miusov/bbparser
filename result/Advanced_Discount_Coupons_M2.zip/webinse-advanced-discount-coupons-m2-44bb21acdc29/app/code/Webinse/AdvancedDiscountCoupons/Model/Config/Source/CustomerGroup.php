<?php

/**
 * Webinse
 *
 * PHP Version 5.6.23
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */
/**
 * Array for customer group in section
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */

namespace Webinse\AdvancedDiscountCoupons\Model\Config\Source;

use  Magento\Customer\Model\ResourceModel\Group\Collection;

class CustomerGroup extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
    implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @var Collection
     */
    protected $_customerGroup;

    public function __construct(
        Collection $customerGroup
    ) {
        $this->_customerGroup = $customerGroup;
    }

    public function getAllOptions()
    {
        $customerGroups = $this->_customerGroup->toOptionArray();
        return $customerGroups;
    }

    public function toArray() {
        $customerGroups = $this->_customerGroup->toArray();
        return $customerGroups;
    }

    final public function toOptionArray() {
        $customerGroups = $this->_customerGroup->toOptionArray();
        return $customerGroups;
    }

}
<?php

/**
 * Webinse
 *
 * PHP Version 5.6.23
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */

/**
 * Coupon class for creating coupons
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */

namespace Webinse\AdvancedDiscountCoupons\Model;

use Magento\Customer\Model\ResourceModel\Customer\CollectionFactory;
use Magento\SalesRule\Model\Rule;
use Magento\SalesRule\Model\Coupon\Massgenerator;
use Magento\SalesRule\Model\CouponFactory;
use Webinse\AdvancedDiscountCoupons\Helper\Data;
use Webinse\AdvancedDiscountCoupons\Model\Email;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Request\Http;
use \Magento\Directory\Model\Currency;

class Coupons
{
    /**
     * @var CollectionFactory
     */
    protected $_collectionFactory;

    /**
     * @var Rule
     */
    protected $_rule;

    /**
     * @var Massgenerator
     */
    protected $_coupon;

    /**
     * @var CouponFactory
     */
    protected $_cop;

    /**
     * @var Data
     */
    protected $_helper;

    /**
     * @var \Webinse\AdvancedDiscountCoupons\Model\Email
     */
    protected $_email;

    protected $_storeManager;

    /**
     * @var Session
     */
    protected $_session;

    protected $_http;

    /**
     * Coupon constructor.
     * @param CollectionFactory $collectionFactory
     * @param Rule $rule
     * @param Massgenerator $coupon
     * @param CouponFactory $cop
     * @param Data $helper
     * @param \Webinse\AdvancedDiscountCoupons\Model\Email $email
     * @param Session $session
     */
    public function __construct(
        CollectionFactory $collectionFactory,
        Rule $rule,
        Massgenerator $coupon,
        CouponFactory $cop,
        Data $helper,
        Email $email,
        Session $session,
        Http $http,
        Currency $storeManager
    )
    {
        $this->_collectionFactory = $collectionFactory;
        $this->_rule = $rule;
        $this->_coupon = $coupon;
        $this->_cop = $cop;
        $this->_helper = $helper;
        $this->_email = $email;
        $this->_session = $session;
        $this->_http = $http;
        $this->_storeManager = $storeManager;
    }

    public function createCoupon($couponParams, $generatorParams, $couponType)
    {
        $helper = $this->_helper;

        $generator = $this->_coupon;

        $cop = $this->_cop;

        if (!empty($generatorParams['format'])) {
            switch (strtolower($generatorParams['format'])) {
                case 'alphanumeric':
                case 'alphanum':
                    $generator->setFormat(\Magento\SalesRule\Helper\Coupon::COUPON_FORMAT_ALPHANUMERIC);
                    break;
                case 'alphabetical':
                case 'alpha':
                    $generator->setFormat(\Magento\SalesRule\Helper\Coupon::COUPON_FORMAT_ALPHABETICAL);
                    break;
                case 'numeric':
                case 'num':
                    $generator->setFormat(\Magento\SalesRule\Helper\Coupon::COUPON_FORMAT_NUMERIC);
                    break;
            }
        }

        $shoppingCartPriceRule = $this->_rule;
        $shoppingCartPriceRule->setName($couponParams['name'])
            ->setDescription($couponParams['desc'])
            ->setFromDate($couponParams['start'])
            ->setToDate($couponParams['end'])
            ->setUsesPerCustomer($couponParams['max_redemptions'])
            ->setCustomerGroupIds($couponParams['customer_groups'])
            ->setIsActive(TRUE)
            ->setSimpleAction($couponParams['discount_type'])
            ->setDiscountAmount($couponParams['discount_amount'])
            ->setApplyToShipping($couponParams['flag_is_free_shipping'])
            ->setTimesUsed($couponParams['redemptions'])
            ->setWebsiteIds($couponParams['website_id'])
            ->setCouponType(2)
            ->setUseAutoGeneration('1')
            ->setUsesPerCoupon(1);

        $shoppingCartPriceRule->setCouponCodeGenerator($generator);
        $shoppingCartPriceRule->save();

        $generator->setDash(!empty($generatorParams['dash_every_x_characters']) ? (int)$generatorParams['dash_every_x_characters'] : 0);
        $generator->setLength(!empty($generatorParams['length']) ? (int)$generatorParams['length'] : 6);
        $generator->setPrefix(!empty($generatorParams['prefix']) ? $generatorParams['prefix'] : '');
        $generator->setSuffix(!empty($generatorParams['suffix']) ? $generatorParams['suffix'] : '');
        $generator->setCouponQty($generatorParams['count']);

        $param = $this->_http->getParams();
        for ($i = 0; $i < $generatorParams['count']; $i++) {
            $om = \Magento\Framework\App\ObjectManager::getInstance();
            $couponCode = $om->create('Magento\SalesRule\Model\Coupon');
            $couponCode
                ->setUsagePerCustomer(1)
                ->setUsageLimit(1)
                ->setCreatedAt(time())
                ->setCode($generator->generateCode())
                ->setType(1)
                ->setRuleId($shoppingCartPriceRule->getId());
            if ($couponType == 'customer_registration') {
                $emailTemplateVariables = array(
                    'couponCode' => $couponCode->getCode(),
                    'customerName' => $param['firstname'] . " " . $param['lastname'],
                    'subject' => $helper->getSubject(),
                    'expireDay' => date('d.m.Y', strtotime($shoppingCartPriceRule->getToDate())),
                    'discountType' => $shoppingCartPriceRule->getSimpleAction() == 'by_percent' ? $couponParams['discount_amount'] . '%' : $this->_storeManager->getCurrencySymbol() . number_format($couponParams['discount_amount'], 2, '.', '')
                );
                $receiverInfo = ['name' => $param['firstname'], 'email' => $param['email']
                ];
            } elseif ($couponType == 'order_count') {
                $emailTemplateVariables = array(
                    'couponCode' => $couponCode->getCode(),
                    'customerName' => $this->_session->getCustomer()->getName(),
                    'subject' => $helper->getSubject(),
                    'expireDay' => date('d.m.Y', strtotime($shoppingCartPriceRule->getToDate())),
                    'discountType' => $shoppingCartPriceRule->getSimpleAction() == 'by_percent' ? $couponParams['discount_amount'] . '%' : $this->_storeManager->getCurrencySymbol() . number_format($couponParams['discount_amount'], 2, '.', ''),
                    'orderNumber' => $helper->numberOfOrders(),
                );
                $receiverInfo = ['name' => $this->_session->getCustomer()->getName(), 'email' => $this->_session->getCustomer()->getEmail()
                ];
            } elseif ($couponType == 'birthday') {
                $emailTemplateVariables = array(
                    'couponCode' => $couponCode->getCode(),
                    'customerName' => $couponParams['customer'][$i]['customer_name'],
                    'subject' => $helper->getSubject(),
                    'expireDay' => date('d.m.Y', strtotime($shoppingCartPriceRule->getToDate())),
                    'discountType' => $shoppingCartPriceRule->getSimpleAction() == 'by_percent' ? $couponParams['discount_amount'] . '%' : $this->_storeManager->getCurrencySymbol() . number_format($couponParams['discount_amount'], 2, '.', ''),
                    'startDay' => date('d.m.Y', strtotime($couponParams['start']))
                );
                $receiverInfo = ['name' => $this->_session->getCustomer()->getName(), 'email' => $couponParams['customer'][$i]['email']
                ];
            } elseif ($couponType == 'per_day_activity') {
                $emailTemplateVariables = array(
                    'couponCode' => $couponCode->getCode(),
                    'customerName' => $couponParams['customer'][$i]['customer_name'],
                    'subject' => $helper->getSubject(),
                    'expireDay' => date('d.m.Y', strtotime($shoppingCartPriceRule->getToDate())),
                    'discountType' => $shoppingCartPriceRule->getSimpleAction() == 'by_percent' ? $couponParams['discount_amount'] . '%' : $this->_storeManager->getCurrencySymbol() . number_format($couponParams['discount_amount'], 2, '.', ''),
                );
                $receiverInfo = ['name' => $this->_session->getCustomer()->getName(), 'email' => $couponParams['customer'][$i]['email']
                ];
            } elseif ($couponType == 'not_activity') {
                $emailTemplateVariables = array(
                    'couponCode' => $couponCode->getCode(),
                    'customerName' => $couponParams['customer'][$i]['customer_name'],
                    'subject' => $helper->getSubject(),
                    'expireDay' => date('d.m.Y', strtotime($shoppingCartPriceRule->getToDate())),
                    'discountType' => $shoppingCartPriceRule->getSimpleAction() == 'by_percent' ? $couponParams['discount_amount'] . '%' : $this->_storeManager->getCurrencySymbol() . number_format($couponParams['discount_amount'], 2, '.', ''),
                    'lastDay' => date('d.m.Y', strtotime($couponParams['customer'][$i]['visit_date']))
                );
                $receiverInfo = ['name' => $this->_session->getCustomer()->getName(), 'email' => $couponParams['customer'][$i]['email']
                ];
            } elseif ($couponType == 'holiday') {
                $emailTemplateVariables = array(
                    'couponCode' => $couponCode->getCode(),
                    'customerName' => $couponParams['customer'][$i]['customer_name'],
                    'subject' => $helper->getSubject(),
                    'expireDay' => date('d.m.Y', strtotime($shoppingCartPriceRule->getToDate())),
                    'discountType' => $shoppingCartPriceRule->getSimpleAction() == 'by_percent' ? $couponParams['discount_amount'] . '%' : $this->_storeManager->getCurrencySymbol() . number_format($couponParams['discount_amount'], 2, '.', ''),
                    'fromDate' => date('d.m.Y', strtotime($couponParams['start'])),
                    'toDate' => date('d.m.Y', strtotime($couponParams['end'])),
                    'holidayName' => $helper->nameHoliday()
                );
                $receiverInfo = ['name' => $this->_session->getCustomer()->getName(), 'email' => $couponParams['customer'][$i]['email']
                ];
            }
            $this->_email->sendEmail($emailTemplateVariables, $receiverInfo, $couponType);
            $couponCode->save();

        }
    }
}
<?php

/**
 * Webinse
 *
 * PHP Version 5.6.23
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */
/**
 * Model for sending email to customer
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */

namespace Webinse\AdvancedDiscountCoupons\Model;

use Magento\Store\Model\StoreManager;
use Webinse\AdvancedDiscountCoupons\Helper\Data;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;

class Email
{
    const BIRTHDAY_EMAIL_TEMPLATE = 'customer_birthday/email_template';
    const CUSTOMER_REGISTRATION_EMAIL_TEMPLATE = 'customer_registration/email_template';
    const PER_DAY_ACTIVITY_EMAIL_TEMPLATE = 'per_day_active_customer/email_template';
    const NOT_ACTIVITY_CUSTOMER = 'not_active_customer/email_template';
    const ORDER_COUNT_EMAIL_TEMPLATE = 'order_count/email_template';
    const HOLIDAYS_EMAIL_TEMPLATE = 'coupon_holidays/email_template';

    /**
     * @var StateInterface
     */
    protected $_inlineTranslation;

    /**
     * @var TransportBuilder
     */
    protected $_transportBuilder;

    /**
     * @var StoreManager
     */
    protected $_storeManager;

    protected $temp_id;

    /**
     * @var Data
     */
    protected $_data;

    /**
     * Email constructor.
     * @param StoreManager $storeManager
     * @param Data $data
     * @param TransportBuilder $transportBuilder
     * @param StateInterface $inlineTranslation
     */
    public function __construct(
        StoreManager $storeManager,
        Data $data,
        TransportBuilder $transportBuilder,
        StateInterface $inlineTranslation
    )
    {
        $this->_storeManager = $storeManager;
        $this->_data = $data;
        $this->_transportBuilder = $transportBuilder;
        $this->_inlineTranslation = $inlineTranslation;
    }

    public function getTemplateId($xmlPath)
    {
        return $this->_data->_getConfig($xmlPath);
    }

    public function generateTemplate($emailTemplateVariables, $senderInfo, $receiverInfo)
    {
        $this->_transportBuilder->setTemplateIdentifier($this->temp_id)
            ->setTemplateOptions(
                [
                    'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                    'store' => $this->_storeManager->getStore()->getId(),
                ]
            )
            ->setTemplateVars($emailTemplateVariables)
            ->setFrom($senderInfo)
            ->addTo($receiverInfo['email'], $receiverInfo['name']);
        return $this;
    }

    /**
     * @param $emailTemplateVariables
     * @param $senderInfo
     * @param $receiverInfo
     * @param $couponType
     */
    public function sendEmail($emailTemplateVariables, $receiverInfo, $couponType)
    {
        switch ($couponType){
            case 'birthday':
                $template = self::BIRTHDAY_EMAIL_TEMPLATE;
                break;
            case 'customer_registration':
                $template = self::CUSTOMER_REGISTRATION_EMAIL_TEMPLATE;
                break;
            case 'per_day_activity':
                $template = self::PER_DAY_ACTIVITY_EMAIL_TEMPLATE;
                break;
            case 'not_activity':
                $template = self::NOT_ACTIVITY_CUSTOMER;
                break;
            case 'order_count':
                $template = self::ORDER_COUNT_EMAIL_TEMPLATE;
                break;
            case 'holiday':
                $template = self::HOLIDAYS_EMAIL_TEMPLATE;
                break;
            default:
                $template = NULL;
                break;
        }

        if ($template != NULL) {
            $this->temp_id = $this->getTemplateId($template);
            $this->_inlineTranslation->suspend();
            $senderInfo = [
                'name' => $this->_data->getSenderName(),
                'email' => $this->_data->getSenderEmail(),
            ];
            $this->generateTemplate($emailTemplateVariables, $senderInfo, $receiverInfo);
            $transport = $this->_transportBuilder->getTransport();
            $transport->sendMessage();
            $this->_inlineTranslation->resume();
        }
    }
}
<?php

/**
 * Webinse
 *
 * PHP Version 5.6.23
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */
/**
 * Controller creation coupon for holiday
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */

namespace Webinse\AdvancedDiscountCoupons\Controller\Adminhtml\Holidaycoupon;

use Magento\Backend\App\Action;
use Webinse\AdvancedDiscountCoupons\Helper\Data;
use Magento\Customer\Model\ResourceModel\Customer\CollectionFactory;
use Webinse\AdvancedDiscountCoupons\Model\Coupons;

class Index extends Action
{
    /**
     * @var Data
     */
    protected $_data;

    /**
     * @var CollectionFactory
     */
    protected $_collectionFactory;

    /**
     * @var Coupons
     */
    protected $_modelCoupon;

    /**
     * Index constructor.
     * @param Action\Context $context
     * @param Data $helper
     * @param CollectionFactory $collectionFactory
     * @param Coupons $modelCoupon
     */
    public function __construct(
        Action\Context $context,
        Data $helper,
        CollectionFactory $collectionFactory,
        Coupons $modelCoupon
    )
    {
        $this->_data = $helper;
        $this->_collectionFactory = $collectionFactory;
        $this->_modelCoupon = $modelCoupon;
        parent::__construct($context);
    }

    public function execute()
    {
        $redirect = $this->resultRedirectFactory->create();
        $helper = $this->_data;

        if ($helper->isModuleHolidayEnable()){
            $customerArray = array();
            $i = 0;
            foreach ($this->_collectionFactory->create()->getItems() as $customer) {
                $a = $i++;
                $customerArray[$a]['email'] = $customer->getEmail();
                $customerArray[$a]['customer_name'] = $customer->getName();
            }

            if (!empty(count($customerArray))) {

                $parameters = array(
                    'count' => count($customerArray),
                    'format' => 'alphanumeric',
                    'dash_every_x_characters' => 4,
                    'length' => 20
                );

                $coupon['name'] = 'Holiday Coupons';
                $coupon['desc'] = 'Holiday Coupons.';
                $coupon['start'] = date("Y-m-d", strtotime($helper->startDateHoliday()));
                $coupon['end'] = date("Y-m-d", strtotime('+' . $helper->expireDayHoliday() . ' day', strtotime($helper->startDateHoliday())));
                $coupon['max_redemptions'] = 1;
                $coupon['discount_type'] = $helper->discountTypeHoliday();
                $coupon['discount_amount'] = $helper->discountAmountHoliday();
                $coupon['flag_is_free_shipping'] = 'no';
                $coupon['redemptions'] = 1;
                $coupon['website_id'] = $helper->storeHoliday();
                $coupon['customer_groups'] = $helper->customerGroupHoliday();
                $coupon['customer'] = $customerArray;

                $this->_modelCoupon->createCoupon($coupon, $parameters, 'holiday');
            }
        }

        $this->messageManager->addSuccessMessage('Coupon for holiday has been created');

        return $redirect->setUrl($this->_redirect->getRefererUrl());
    }
}
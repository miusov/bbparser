<?php

/**
 * Webinse
 *
 * PHP Version 5.6.23
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */
/**
 * Creating coupon after success full register
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */

namespace Webinse\AdvancedDiscountCoupons\Observer;

use Magento\Framework\Event\ObserverInterface;
use Webinse\AdvancedDiscountCoupons\Helper\Data;
use Webinse\AdvancedDiscountCoupons\Model\Coupons;
use Webinse\AdvancedDiscountCoupons\Model\Email;
use Magento\Customer\Model\Session;

class CouponAfterSuccessRegisterCustomer implements ObserverInterface
{
    /**
     * @var Session
     */
    protected $_session;
    /**
     * @var Data
     */
    protected $_helper;

    /**
     * @var Coupons
     */
    protected $_modelCoupon;

    /**
     * @var Email
     */
    protected $_sentEmail;

    /**
     * CouponAfterSuccessRegisterCustomer constructor.
     * @param Data $data
     * @param Coupons $couponModel
     * @param Email $email
     * @param Session $session
     */
    public function __construct(
        Data $data,
        Coupons $couponModel,
        Email $email,
        Session $session
    )
    {
        $this->_helper = $data;
        $this->_modelCoupon = $couponModel;
        $this->_sentEmail = $email;
        $this->_session =  $session;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $helper = $this->_helper;
        if ($helper->isModuleRegisterEnable()) {

            $parameters = array(
                'count' => 1,
                'format' => 'alphanumeric',
                'dash_every_x_characters' => 4,
                'length' => 20
            );

            $coupon['name'] = 'Register Coupon';
            $coupon['desc'] = 'Register Coupons.';
            $coupon['start'] = date("Y-m-d", time());
            $coupon['end'] = date("Y-m-d", strtotime('+' . $helper->expireDayRegister() . ' day', time()));
            $coupon['max_redemptions'] = 1;
            $coupon['discount_type'] = $helper->discountTypeRegister();
            $coupon['discount_amount'] = $helper->discountAmountRegister();
            $coupon['flag_is_free_shipping'] = 'no';
            $coupon['redemptions'] = 1;
            $coupon['website_id'] = $helper->storeRegister();
            $coupon['customer_groups'] = $helper->customerGroupRegister();

            $this->_modelCoupon->createCoupon($coupon, $parameters, 'customer_registration');
        }
    }
}
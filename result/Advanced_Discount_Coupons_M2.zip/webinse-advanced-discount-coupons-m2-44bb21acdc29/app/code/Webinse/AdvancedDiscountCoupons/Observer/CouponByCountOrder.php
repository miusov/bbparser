<?php

/**
 * Webinse
 *
 * PHP Version 5.6.23
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */
/**
 * Creating coupon after success full checkout by order count
 *
 * @category    Webinse
 * @package     Webinse_AdvancedDiscountCoupons
 * @author      Webinse Team <info@webinse.com>
 * @copyright   2017 Webinse Ltd. (https://www.webinse.com)
 * @license     http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0
 */

namespace Webinse\AdvancedDiscountCoupons\Observer;

use Magento\Framework\Event\ObserverInterface;
use Webinse\AdvancedDiscountCoupons\Helper\Data;
use Webinse\AdvancedDiscountCoupons\Model\Coupons;
use Magento\Sales\Model\OrderFactory;
use Magento\Customer\Model\Session;

class CouponByCountOrder implements ObserverInterface
{
    /**
     * @var Data
     */
    protected $_helper;

    /**
     * @var Coupons
     */
    protected $_modelCoupon;

    /**
     * @var OrderFactory
     */
    protected $_orderFactory;

    /**
     * @var Session
     */
    protected $_session;

    /**
     * CouponByCountOrder constructor.
     * @param Data $data
     * @param Coupons $couponModel
     * @param OrderFactory $orderFactory
     * @param Session $session
     */
    public function __construct(
        Data $data,
        Coupons $couponModel,
        OrderFactory $orderFactory,
        Session $session
    )
    {
        $this->_helper = $data;
        $this->_modelCoupon = $couponModel;
        $this->_orderFactory = $orderFactory;
        $this->_session = $session;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $helper = $this->_helper;
        if ($helper->isModuleOrderEnable()) {
            $order = $this->_orderFactory->create();

            if (count($order->getCollection()->addFieldToFilter('customer_id', $this->_session->getCustomer()->getId())) == $helper->numberOfOrders()) {

                $parameters = array(
                    'count' => 1,
                    'format' => 'alphanumeric',
                    'dash_every_x_characters' => 4,
                    'length' => 20
                );

                $coupon['name'] = 'Order Count Discount Coupon For Customer ';
                $coupon['desc'] = 'Discount for Per day Activity Customer.';
                $coupon['start'] = date("Y-m-d", time());
                $coupon['end'] = date("Y-m-d", strtotime('+' . $helper->expireDayOrder() . ' day', time()));
                $coupon['max_redemptions'] = 1;
                $coupon['discount_type'] = $helper->discountTypeOrder();
                $coupon['discount_amount'] = $helper->discountAmountOrder();
                $coupon['flag_is_free_shipping'] = 'no';
                $coupon['redemptions'] = 1;
                $coupon['website_id'] = $helper->storeOrder();
                $coupon['customer_groups'] = $helper->customerGroupOrder();

                $this->_modelCoupon->createCoupon($coupon, $parameters, 'order_count');
            }
        }

    }
}
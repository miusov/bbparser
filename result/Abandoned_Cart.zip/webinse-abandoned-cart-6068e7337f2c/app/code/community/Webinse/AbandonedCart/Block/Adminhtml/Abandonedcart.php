<?php
/**
 * Created by PhpStorm.
 * User: andrey
 * Date: 8/18/14
 * Time: 3:46 PM
 */
class Webinse_AbandonedCart_Block_Adminhtml_Abandonedcart extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
        $this->_blockGroup = 'webinse_abandonedcart';
        $this->_controller = 'adminhtml_abandonedcart';
        $this->_headerText = Mage::helper('webinse_abandonedcart')->__('Customers Cart');

        parent::__construct();
    }
}
<?php

/**
 * Created by PhpStorm.
 * User: andrey
 * Date: 8/18/14
 * Time: 2:20 PM
 */
class Webinse_AbandonedCart_Helper_Data extends Mage_Core_Helper_Abstract
{
    public function getCurrentTime()
    {
        return date("Y-m-d H:i:s", Mage::getModel('core/date')->timestamp(time()));
    }

}
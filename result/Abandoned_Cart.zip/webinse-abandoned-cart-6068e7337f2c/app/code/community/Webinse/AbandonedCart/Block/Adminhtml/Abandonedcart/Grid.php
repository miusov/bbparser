<?php

/**
 * Created by PhpStorm.
 * User: andrey
 * Date: 8/18/14
 * Time: 3:52 PM
 */
class Webinse_AbandonedCart_Block_Adminhtml_Abandonedcart_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct()
    {
        parent::__construct();
        $this->setId('abandonedcart');
        $this->setDefaultSort('identifier');
        $this->setDefaultDir('ASC');
        // $this->setUseAjax(true);
        $this->setSaveParametersInSession(true);
    }

    protected function getStore()
    {
        $storeId = (int)$this->getRequest()->getParam('store', 0);
        return Mage::app()->getStore($storeId);
    }

    protected function _prepareCollection()
    {
        $firstName = Mage::getModel('eav/entity_attribute')->loadByCode('customer', 'firstname');
        $lastName = Mage::getModel('eav/entity_attribute')->loadByCode('customer', 'lastname');
        //prepare collection
        $collection = Mage::getResourceModel('sales/quote_collection')
            ->addFieldToSelect('*')
            ->addFieldToFilter('customer_id', array('notnull' => true))
            ->addFieldToFilter('customer_email', array('notnull' => true));
        $collection
            ->getSelect()
            /*
             *
             * */
            /*->join(
                array('soa' => 'sales_flat_quote_address'),
                'soa.quote_id=main_table.entity_id and soa.address_type = "billing"',
                array(
                    'full_address'=>'CONCAT(soa.street, ",<br/>", soa.city, ",<br/>", )' ),
                null,'left')*/

            /**
             *
             */

          /*
           * 
           *
           *   ->join('sales_flat_quote_item', 'main_table.entity_id = sales_flat_quote_item.quote_id', array('product_sku' => 'sku', 'product_name' => 'name'))*/

            //->join('sales_flat_quote_item', 'main_table.entity_id = sales_flat_quote_item.quote_id', array('product_sku' => 'sku', 'product_name' => 'name'))
            ->join(array('ce1' => 'customer_entity_varchar'), 'ce1.entity_id=main_table.customer_id', array('firstname' => 'value'))
            ->where('ce1.attribute_id=' . $firstName->getAttributeId())
            ->join(array('ce2' => 'customer_entity_varchar'), 'ce2.entity_id=main_table.customer_id', array('lastname' => 'value'))
            ->where('ce2.attribute_id=' . $lastName->getAttributeId())
            ->columns(new Zend_Db_Expr("CONCAT(`ce1`.`value`, ' ',`ce2`.`value`) AS customer_name"));
        //set collection
        $this->setCollection($collection);


        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        $helper = Mage::helper('webinse_abandonedcart');

        $this->addColumn('entity_id', array(
            'header' => $helper->__('entity_id'),
            'index' => 'entity_id',
            'width' => '100px',
        ));
        $this->addColumn('product_name', array(
            'header' => $helper->__('product_name'),
            'index' => 'product_name',

        ));
        /*$this->addColumn('name', array(
            'header' => $helper->__('name'),
            'index' => 'name',

        ));*/


        $this->addColumn('customer_id', array(
            'header' => $helper->__('Customer_ID'),
            'index' => 'customer_id',
            'width' => '100px',
        ));

        $this->addColumn('customer_name', array(
            'header' => $helper->__('Customer Name'),
            'index' => 'customer_name',
            'filter_name' => 'customer_name',
            'filter_index' => 'CONCAT(`ce1`.`value`, `ce2`.`value`)',
        ));

        $this->addColumn('customer_email', array(
            'header' => $helper->__('Customer Email'),
            'index' => 'customer_email',

        ));

        /*$this->addColumn('customer_country', array(
            'header' => $helper->__('Customer Country'),
            'index' => 'customer_country',

        ));
*/
        $this->addColumn('Items_qty', array(
            'header' => $helper->__('Qty'),
            'index' => 'items_qty',

        ));

        $this->addColumn('sku', array(
            'header' => $helper->__('Sku'),
            'index' => 'product_sku',
            'renderer'=>'Webinse_AbandonedCart_Block_Adminhtml_Widget_Grid_Column_Renderer_Item'

        ));

        $this->addColumn('time_in_cart', array(
            'header' => $helper->__('Time In Cart'),
            'index' => 'created_at',
            'renderer'=>'Webinse_AbandonedCart_Block_Adminhtml_Widget_Grid_Column_Renderer_Time'

        ));
        /*
                $this->addColumn('sku', array(
                    'header'    => Mage::helper('catalog')->__('SKU'),
                    'index'     => 'sku',
                    'width'     => '100px',
                ));

                $this->addColumn('qty', array(
                    'header'    => Mage::helper('catalog')->__('Qty'),
                    'index'     => 'qty',
                    'type'      => 'number',
                    'width'     => '60px',
                ));

                $this->addColumn('price', array(
                    'header'        => Mage::helper('catalog')->__('Price'),
                    'index'         => 'price',
                    'type'          => 'currency',
                    'currency_code' => (string) Mage::getStoreConfig(Mage_Directory_Model_Currency::XML_PATH_CURRENCY_BASE),
                ));

                $this->addColumn('total', array(
                    'header'        => Mage::helper('sales')->__('Total'),
                    'index'         => 'row_total',
                    'type'          => 'currency',
                    'currency_code' => (string) Mage::getStoreConfig(Mage_Directory_Model_Currency::XML_PATH_CURRENCY_BASE),
                ));

                $this->addColumn('action', array(
                    'header'    => Mage::helper('customer')->__('Action'),
                    'index'     => 'quote_item_id',
                    'renderer'  => 'adminhtml/customer_grid_renderer_multiaction',
                    'filter'    => false,
                    'sortable'  => false,
                    'actions'   => array(
                        array(
                            'caption'           => Mage::helper('customer')->__('Configure'),
                            'url'               => 'javascript:void(0)',
                            'process'           => 'configurable',
                            'control_object'    => $this->getJsObjectName() . 'cartControl'
                        ),
                        array(
                            'caption'   => Mage::helper('customer')->__('Delete'),
                            'url'       => '#',
                            'onclick'   => 'return ' . $this->getJsObjectName() . 'cartControl.removeItem($item_id);'
                        )
                    )
                ));*/

        return parent::_prepareColumns();
    }
}
<?php

/**
 * Created by PhpStorm.
 * User: andrey
 * Date: 8/18/14
 * Time: 2:21 PM
 */
class Webinse_AbandonedCart_Adminhtml_AbandonedcartController extends Mage_Adminhtml_Controller_Action
{
    protected function _initAction()
    {
        $this->_title($this->__('Abandoned Cart'))
            ->_title($this->__('Webinse'));
        $this->loadLayout()
            ->_setActiveMenu('cc')
            ->_addBreadcrumb(Mage::helper('webinse_abandonedcart')->__('CMS'), Mage::helper('cms')->__('CMS'))
            ->_addBreadcrumb(Mage::helper('webinse_abandonedcart')->__('Abandoned Cart Page'), Mage::helper('webinse_abandonedcart')->__('Abandoned Cart Page'));
        return $this;
    }

    public function listAction()
    {
        $this->_title($this->__('Abandoned Cart'));
        $this->_initAction();
        $this->renderLayout();

    }
}
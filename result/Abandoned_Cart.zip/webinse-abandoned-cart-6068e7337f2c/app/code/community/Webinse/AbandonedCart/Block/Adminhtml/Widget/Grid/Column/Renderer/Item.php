<?php
/**
 * Created by PhpStorm.
 * User: andrey
 * Date: 8/19/14
 * Time: 3:33 PM
 */
class Webinse_AbandonedCart_Block_Adminhtml_Widget_Grid_Column_Renderer_Item extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('webinse/grid/item.phtml');
        return $this;

    }

    public function getItem()
    {
        return $this->getItem();
    }
    public function render(Varien_Object $object)
    {
        $this->setItem($object);
        return $this->toHtml();
    }
}
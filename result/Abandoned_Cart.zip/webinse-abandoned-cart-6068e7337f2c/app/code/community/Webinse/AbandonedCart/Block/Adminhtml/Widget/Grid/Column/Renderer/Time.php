<?php

/**
 * Created by PhpStorm.
 * User: andrey
 * Date: 8/19/14
 * Time: 2:09 PM
 */
class Webinse_AbandonedCart_Block_Adminhtml_Widget_Grid_Column_Renderer_Time extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{
    public function render(Varien_Object $row)
    {
        $createTime = new DateTime($row->getCreatedAt());
        $currentTim = new DateTime(Mage::helper('webinse_abandonedcart')->getCurrentTime());

        $interval = $createTime->diff($currentTim);
        return '<p align="center" style="background-color: #66FFCC">'.$interval->format('%yy/ %mm/ %dd/ - %Hh/ %im/ %ss').'</p>';
    }
}
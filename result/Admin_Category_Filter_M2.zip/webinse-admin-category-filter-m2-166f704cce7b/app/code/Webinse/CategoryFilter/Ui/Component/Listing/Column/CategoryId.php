<?php
/**
​ * ​ ​ Webinse
​ *
​ * ​ ​ PHP​ ​ Version​ ​ 7.0.22
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_CategoryFilter
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */
/**
​ * ​ ​ Comment​ ​ for​ ​ file
​ *
​ * ​ ​ @category     Webinse
​ * ​ ​ @package    ​ ​ Webinse_CategoryFilter
​ * ​ ​ @author       Webinse​ ​ Team​ ​ <info@webinse.com>
​ * ​ ​ @copyright  ​ ​ 2018 ​ Webinse​ ​ Ltd.​ ​ (https://www.webinse.com)
​ * ​ ​ @license    ​ ​ http://opensource.org/licenses/OSL-3.0​ ​ The​ ​ Open​ ​ Software​ ​ License​ ​ 3.0
​ */

namespace Webinse\CategoryFilter\Ui\Component\Listing\Column;

use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Catalog\Model\ProductFactory;
use Magento\Catalog\Model\Category as ModelCategory;
use Webinse\CategoryFilter\Model\Config;

class CategoryId extends Column
{
    /**
     * @var ProductFactory
     */
    protected $_productLoader;
    /**
     * @var ModelCategory
     */
    protected $_categoryLoader;

    /**
     * @var Config
     */
    protected $_config;

    /**
     * CategoryId constructor.
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param ProductFactory $_productLoader
     * @param ModelCategory $_categoryLoader
     * @param Config $config
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        ProductFactory $_productLoader,
        ModelCategory $_categoryLoader,
        Config $config,
        array $components = [],
        array $data = []
    )
    {
        $this->_productLoader   = $_productLoader;
        $this->_categoryLoader  = $_categoryLoader;
        $this->_config          = $config;
        if(!$this->_config->getEnableExtensionYesNo())
        {
            $data = [];
        }
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }
    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        $fieldName = $this->getData('name');
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                $p_id=$item['entity_id'];
                $product=$this->_productLoader->create()->load($p_id);
                $cats = $product->getCategoryIds();
                $categories=array();
                if(count($cats) ){
                    foreach($cats as $cat){
                        $categories[]=$cat;
                    }
                }
                $item[$fieldName]=implode(',',$categories);
            }
        }
        return $dataSource;
    }
}